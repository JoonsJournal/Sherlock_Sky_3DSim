/**
 * env-config.js
 * 런타임 환경 설정 - 중앙 집중식 포트 관리
 * 
 * @version 2.1.0
 * @description
 * - 런타임 환경 변수 주입
 * - UDS Feature Flag 추가 (v2.1.0)
 * 
 * @changelog
 * - v2.1.0: UDS (Unified Data Store) 설정 추가 (2026-01-20)
 *   - UDS_ENABLED: Feature Flag
 *   - UDS_INITIAL_ENDPOINT: 초기 데이터 엔드포인트
 *   - UDS_STREAM_ENDPOINT: WebSocket 스트림 엔드포인트
 *   - UDS_POLL_INTERVAL: Delta 감지 주기
 * - v2.0.0: 중앙 집중식 포트 관리 도입
 *           - BACKEND_PORT, FRONTEND_PORT 상수 추가
 *           - 서버 이전 시 상단 포트 설정만 수정하면 전체 적용
 *           - 기존 기능 100% 유지 (window.ENV 구조 동일)
 * - v1.0.0: 초기 버전 - 접속 호스트 기반 자동 설정
 * 
 * 📌 서버 이전 시 수정할 항목:
 *    - BACKEND_PORT: Backend API 서버 포트
 *    - FRONTEND_PORT: Frontend 서버 포트 (참고용)
 * 
 * 위치: frontend/threejs_viewer/public/env-config.js
 */

(function() {
    // ============================================
    // 🔑 포트 설정 (중앙 관리)
    // 서버 이전 시 이 값들만 수정하세요!
    // ============================================
    const BACKEND_PORT = 8008;   // Backend API 서버 포트
    const FRONTEND_PORT = 8088;  // Frontend 서버 포트 (참고용)
    
    // ============================================
    // 동적 URL 생성
    // ============================================
    // 현재 접속한 호스트를 기반으로 자동 설정
    const currentHost = window.location.hostname;
    
    window.ENV = {
        // 🆕 v2.0.0: 포트 설정 (전역 참조용)
        BACKEND_PORT: BACKEND_PORT,
        FRONTEND_PORT: FRONTEND_PORT,
        
        // 접속한 호스트 기준으로 API URL 자동 생성 (기존 호환)
        API_BASE_URL: `http://${currentHost}:${BACKEND_PORT}/api`,
        WS_URL: `ws://${currentHost}:${BACKEND_PORT}/ws`,
        
        // 디버그 모드 (기존 호환)
        DEBUG_MODE: true,
        
        // 환경 이름 (기존 호환)
        ENVIRONMENT: 'development',
        
        // 추가 설정 (기존 호환)
        MAX_RECONNECT_ATTEMPTS: 10,
        RECONNECT_INTERVAL: 5000,

        // =========================================================
        // 🆕 v2.1.0: UDS (Unified Data Store) 설정
        // =========================================================
        
        /**
         * UDS Feature Flag
         * - true: UDS 방식 사용 (초기 로드 1회 → Delta Update)
         * - false: Legacy 방식 사용 (기존 API 호출)
         */
        UDS_ENABLED: true,
        
        /**
         * UDS 초기 데이터 엔드포인트
         * GET /api/uds/initial
         */
        UDS_INITIAL_ENDPOINT: '/api/uds/initial',
        
        /**
         * UDS WebSocket 스트림 엔드포인트
         * WS /api/uds/stream
         */
        UDS_STREAM_ENDPOINT: '/api/uds/stream',
        
        /**
         * UDS Delta 감지 주기 (ms)
         * Backend에서 이 주기로 변경 감지 후 WebSocket으로 전송
         */
        UDS_POLL_INTERVAL: 10000,  // 10초
        
        /**
         * UDS 초기 로드 타임아웃 (ms)
         * 이 시간 초과 시 Legacy 방식으로 폴백
         */
        UDS_INITIAL_TIMEOUT: 5000  // 5초
    };
    
    // ============================================
    // 로그 출력 (기존 호환)
    // ============================================
    console.log('✓ 런타임 환경 설정 로드됨 (v2.0.0)');
    console.log(`  → Host: ${currentHost}`);
    console.log(`  → Backend Port: ${BACKEND_PORT}`);
    console.log(`  → Frontend Port: ${FRONTEND_PORT}`);
    console.log(`  → API: ${window.ENV.API_BASE_URL}`);
    console.log(`  → WS: ${window.ENV.WS_URL}`);
        // 로드 확인 로그
    console.log('✅ [env-config] 런타임 환경 설정 로드됨 (v2.1.0)');
    console.log(`   └─ UDS_ENABLED: ${window.ENV.UDS_ENABLED}`);
    console.log(`   └─ API_BASE_URL: ${window.ENV.API_BASE_URL}`);
})();
