/**
 * RankingView.js
 * ==============
 * Ranking View 메인 컨트롤러 (Orchestrator)
 * 
 * @version 1.8.0
 * @description
 * - 6개 레인 레이아웃 관리 (Remote, Sudden Stop, Stop, Run, Idle, Wait)
 * - 레인 컴포넌트 생성 및 조율
 * - EventBus 이벤트 구독/라우팅
 * - show()/hide()/dispose() 라이프사이클 관리
 * - Equipment Info Drawer 연동
 * - CameraNavigator 가시성 제어 (3D View 전용)
 * - Dev Mode 자동 테스트 데이터 지원
 * - Custom 레인 지원 (Phase 6)
 * - 긴급도 통계 바 (Phase 6)
 * - 🆕 UDS (Unified Data Store) 연동 (Phase 3)
 * - 🆕 3D View 선택 동기화 강화
 * 
 * @changelog
 * - v1.8.0: 🆕 StatusBar 레인 통계 동기화 이벤트 추가 (2026-01-27)
 *           - _updateStats()에서 ranking:lane-stats-updated 이벤트 발행
 *           - _getDisconnectedCount() 메서드 추가
 * - v1.7.2 (2026-01-27): 🐛 BugFix - Ghost DOM 원천 차단
 *   - _handleUDSBatchUpdate()에서 _renderLaneData() 호출 제거
 *   - 개별 설비 이동은 EQUIPMENT_MOVED 이벤트에서 처리
 *   - BATCH_UPDATED에서는 통계만 업데이트
 *   - 2개 경로 → 1개 경로로 통일하여 Ghost 발생 원천 차단
 *   - ⚠️ 호환성: v1.7.1의 모든 기능 100% 유지
 * - v1.7.1 (2026-01-26): 🐛 BugFix - Ghost DOM 버그 수정
 *   - _handleEquipmentMoved()에서 _cards Map 동기화 추가
 *   - ranking-view-test.html과 동일한 로직 적용
 *   - 애니메이션 완료 후 fromLane._cards.delete() + toLane._cards.set()
 *   - ⚠️ 호환성: v1.7.0의 모든 기능 100% 유지
 * - v1.7.0: 🆕 레인 이동 개선 (Phase 4)
 *   - _handleEquipmentMoved() 로직 개선
 *   - 정렬 기준 기반 삽입 위치 계산 (calculateBatchInsertIndices 사용)
 *   - 복수 설비 동시 이동 지원
 *   - 카드 UI 전체 업데이트 연동 (onComplete 콜백)
 *   - _groupMovesByTargetLane() 메서드 추가
 *   - _prepareUpdatedData() 메서드 추가
 *   - _updateCardUI() 메서드 추가
 *   - ⚠️ 호환성: v1.6.0의 모든 기능 100% 유지
 * - v1.6.0: 🆕 AnimationManager 연동
 *   - _cardsMap 추가 (전체 카드 인스턴스 관리)
 *   - _createAnimationManager() 메서드 추가
 *   - _handleEquipmentMoved() 애니메이션 적용
 *   - 레인 이동 시 4-Phase 애니메이션 실행
 *   - ⚠️ 호환성: v1.5.0의 모든 기능 100% 유지
 * - v1.5.0: 🆕 Phase 3 Day 2 - UDS 연동 및 3D View 동기화
 *   - _subscribeToUDSEvents(): UDS 이벤트 구독
 *   - _initializeFromUDS(): UDS 데이터로 초기화
 *   - _handleUDSInitialized(): UDS 초기화 완료 처리
 *   - _handleUDSEquipmentUpdate(): UDS 설비 업데이트 처리
 *   - _handleRankingsUpdate(): 순위 업데이트 처리
 *   - _sync3DViewSelection(): 3D View 선택 동기화
 *   - _renderLaneData(): Lane 데이터 렌더링
 *   - _updateLaneCards(): Lane 카드 업데이트
 *   - RankingDataManager 연동 강화
 *   - 3D View ↔ Ranking View 양방향 선택 동기화
 *   - ⚠️ 호환성: v1.4.0의 모든 기능 100% 유지
 * - v1.4.0: 🆕 Phase 6 - Custom 레인 + 긴급도 통계 기능 추가
 * - v1.3.1: 🐛 Bug Fix - CameraNavigator 숨김 강화 + Dev Mode 지원
 * - v1.3.0: 🆕 Phase 5 - LaneManager 통합
 * - v1.2.0: CameraNavigator 가시성 제어 추가
 * - v1.1.0: Phase 2 업데이트
 * - v1.0.0: Phase 1 초기 버전
 * 
 * @dependencies
 * - EventBus (src/core/managers/EventBus.js)
 * - RankingLane (./components/RankingLane.js)
 * - EquipmentCard (./components/EquipmentCard.js)
 * - LaneManager (./managers/LaneManager.js)
 * - 🆕 RankingDataManager (./managers/RankingDataManager.js)
 * - 🆕 UnifiedDataStore (../../services/uds/UnifiedDataStore.js)
 * 
 * @exports
 * - RankingView
 * 
 * 📁 위치: frontend/threejs_viewer/src/ui/ranking-view/RankingView.js
 * 작성일: 2026-01-17
 * 수정일: 2026-01-21
 */

import { eventBus } from '../../core/managers/EventBus.js';
import { RankingLane } from './components/RankingLane.js';
import { EquipmentCard } from './components/EquipmentCard.js';
// 🆕 v1.3.0: LaneManager import
import { LaneManager } from './managers/LaneManager.js';
// 🆕 v1.5.0: UDS 및 RankingDataManager import
import { RankingDataManager } from './managers/RankingDataManager.js';
// 🆕 v1.6.0: AnimationManager import
import { AnimationManager } from './managers/AnimationManager.js';
import { unifiedDataStore, UnifiedDataStore } from '../../services/uds/UnifiedDataStore.js';

/**
 * 레인 설정 정의
 */
const LANE_CONFIG = [
    {
        id: 'remote',
        name: 'Remote',
        icon: '🔴',
        description: 'Remote 알람 발생 설비',
        sortKey: 'duration',
        sortOrder: 'desc'
    },
    {
        id: 'sudden-stop',
        name: 'Sudden Stop',
        icon: '🛑',  // ✅ 변경: Stop과 동일 (CSS 깜빡임으로 구분)
        description: '급정지 상태 설비',
        sortKey: 'duration',
        sortOrder: 'desc'
    },
    {
        id: 'stop',
        name: 'Stop',
        icon: '🛑',
        description: '정지 상태 설비',
        sortKey: 'duration',
        sortOrder: 'desc'
    },
    {
        id: 'run',
        name: 'Run',
        icon: '🟢',
        description: '가동 중 설비',
        sortKey: 'production',
        sortOrder: 'desc'
    },
    {
        id: 'idle',
        name: 'Idle',
        icon: '🟡',
        description: '대기 상태 설비',
        sortKey: 'duration',
        sortOrder: 'desc'
    },
    {
        id: 'wait',
        name: 'Wait',
        icon: '⏸️',
        description: 'Lot 없음 (비생산 대기)',
        sortKey: 'duration',
        sortOrder: 'desc'
    }
];

/**
 * 🆕 v1.4.0: Custom 레인 필터 옵션
 */
const CUSTOM_FILTER_OPTIONS = [
    { value: 'alarm-code', label: '알람 코드별', icon: '🔔' },
    { value: 'line', label: '라인별', icon: '🏭' },
    { value: 'equipment-type', label: '설비 타입별', icon: '⚙️' },
    { value: 'urgency', label: '긴급도별', icon: '⚠️' },
    { value: 'production', label: '생산량별', icon: '📊' }
];

export class RankingView {
    /**
     * CSS 클래스 상수 정의
     */
    static CSS = {
        // Block
        BLOCK: 'ranking-view',
        
        // Elements
        HEADER: 'ranking-view__header',
        TITLE: 'ranking-view__title',
        CONTROLS: 'ranking-view__controls',
        CUSTOM_LANE_CONTROLS: 'ranking-view__custom-lane-controls',
        LANES_CONTAINER: 'ranking-view__lanes-container',
        STATS_BAR: 'ranking-view__stats-bar',
        STAT: 'ranking-view__stat',
        STAT_LABEL: 'ranking-view__stat-label',
        STAT_VALUE: 'ranking-view__stat-value',
        LOADING: 'ranking-view__loading',
        LOADING_SPINNER: 'ranking-view__loading-spinner',
        LOADING_TEXT: 'ranking-view__loading-text',
        EMPTY: 'ranking-view__empty',
        EMPTY_ICON: 'ranking-view__empty-icon',
        EMPTY_TITLE: 'ranking-view__empty-title',
        EMPTY_MESSAGE: 'ranking-view__empty-message',
        
        // Modifiers
        HIDDEN: 'ranking-view--hidden',
        LOADING_STATE: 'ranking-view--loading',
        EMPTY_STATE: 'ranking-view--empty',
        ACTIVE: 'ranking-view--active',
        
        // Legacy alias (하위 호환)
        LEGACY_HIDDEN: 'hidden',
        LEGACY_ACTIVE: 'active',
        LEGACY_LOADING: 'loading'
    };
    
    /**
     * Utility 클래스 상수
     */
    static UTIL = {
        FLEX: 'u-flex',
        FLEX_COL: 'u-flex-col',
        GAP_2: 'u-gap-2'
    };
    
    /**
     * 🆕 v1.4.0: 설정
     */
    static CONFIG = {
        ENABLE_CUSTOM_LANES: true,
        MAX_CUSTOM_LANES: 3,
        // 🆕 v1.5.0: UDS 설정
        USE_UDS: true
    };
    
    /**
     * @param {Object} options - 설정 옵션
     * @param {HTMLElement} options.container - 부모 컨테이너
     * @param {Object} options.webSocketClient - WebSocket 클라이언트 (선택)
     */
    constructor(options = {}) {
        console.log('[RankingView] 🚀 초기화 시작 (v1.5.0 - Phase 3 UDS 연동)...');
        
        // Options
        this._container = options.container || document.body;
        this._webSocketClient = options.webSocketClient || null;
        
        // 🆕 v1.4.0: Custom 레인 설정
        this._enableCustomLanes = options.enableCustomLanes ?? RankingView.CONFIG.ENABLE_CUSTOM_LANES;
        
        // 🆕 v1.5.0: UDS 설정
        this._useUDS = options.useUDS ?? (window.ENV_CONFIG?.UDS_ENABLED ?? RankingView.CONFIG.USE_UDS);
        this._udsInitialized = false;
        
        // State
        this._isVisible = false;
        this._isInitialized = false;
        this._isLoading = false;
        this._selectedEquipmentId = null;
        this._focusedLaneIndex = 0;
        
        // 🆕 v1.3.1: Dev Mode 감지
        this._isDevMode = this._detectDevMode();
        
        // 🆕 v1.2.0: CameraNavigator 이전 가시성 상태 저장
        this._cameraNavigatorWasVisible = true;
        
        // 🆕 v1.4.0: Custom 레인 저장
        this._customLanes = new Map();
        
        // DOM References
        this.element = null;
        this._headerElement = null;
        this._lanesContainer = null;
        this._statsBar = null;
        this._loadingElement = null;
        this._emptyElement = null;
        this._customLaneSelect = null;
        this._customLaneAddBtn = null;
        
        // Components
        this._lanes = new Map(); // Map<laneId, RankingLane>

        // 🆕 v1.6.0: 전체 카드 인스턴스 관리
        this._cardsMap = new Map(); // Map<frontendId, EquipmentCard>
        
        // 🆕 v1.3.0: LaneManager 인스턴스
        this._laneManager = null;

        // 🆕 v1.6.0: AnimationManager 인스턴스
        this._animationManager = null;
        
        // 🆕 v1.5.0: RankingDataManager 인스턴스
        this._rankingDataManager = null;
        
        // Event Handlers (for cleanup)
        this._boundHandlers = {};
        this._eventSubscriptions = [];
        
        // Initialize
        this._init();
    }
    
    // =========================================
    // Lifecycle Methods
    // =========================================
    
    /**
     * 초기화
     * @private
     */
    _init() {
        console.log('[RankingView] 📊 _init()');
        
        this._createDOM();
        this._createLanes();
        this._createLaneManager();  // 🆕 v1.3.0
        this._createAnimationManager();  // 🆕 v1.6.0
        this._createRankingDataManager();  // 🆕 v1.5.0
        this._setupEventListeners();
        
        // 🆕 v1.5.0: UDS 이벤트 구독
        if (this._useUDS) {
            this._subscribeToUDSEvents();
        }
        
        this._isInitialized = true;
        console.log('[RankingView] ✅ 초기화 완료 (v1.5.0)');
    }
    
    /**
     * 🆕 v1.5.0: RankingDataManager 생성
     * @private
     */
    _createRankingDataManager() {
        console.log('[RankingView] 📊 _createRankingDataManager()');
        
        this._rankingDataManager = new RankingDataManager({
            eventBus: eventBus,
            webSocketClient: this._webSocketClient,
            useUDS: this._useUDS
        });
        
        // RankingDataManager 이벤트 구독
        this._eventSubscriptions.push(
            // 데이터 새로고침 시
            eventBus.on(RankingDataManager.EVENTS.DATA_REFRESHED, (event) => {
                this._handleDataRefreshed(event);
            }),
            
            // 설비 레인 이동 시
            eventBus.on(RankingDataManager.EVENTS.EQUIPMENT_MOVED, (event) => {
                this._handleEquipmentMoved(event);
            }),
            
            // 순위 업데이트 시
            eventBus.on(RankingDataManager.EVENTS.RANKINGS_UPDATED, (event) => {
                this._handleRankingsUpdate(event);
            }),
            
            // 통계 업데이트 시
            eventBus.on(RankingDataManager.EVENTS.STATS_UPDATED, (event) => {
                this._updateStatsFromEvent(event);
            }),
            
            // 🆕 v1.5.0: 3D View 선택 동기화
            eventBus.on(RankingDataManager.EVENTS.SELECTION_SYNC, (event) => {
                this._sync3DViewSelection(event);
            }),
            
            // 설비 하이라이트
            eventBus.on(RankingDataManager.EVENTS.EQUIPMENT_HIGHLIGHT, (event) => {
                this._handleEquipmentHighlight(event);
            })
        );
        
        console.log('[RankingView] ✅ RankingDataManager 생성 완료');
    }
    
    /**
     * 🆕 v1.6.0: AnimationManager 생성
     * @private
     */
    _createAnimationManager() {
        console.log('[RankingView] 🎬 _createAnimationManager()');
        
        this._animationManager = new AnimationManager({
            container: this._lanesContainer,
            lanesMap: this._lanes,
            cardsMap: this._cardsMap
        });
        
        console.log('[RankingView] ✅ AnimationManager 생성 완료');
    }

    /**
     * 🆕 v1.5.0: UDS 이벤트 구독
     * @private
     */
    _subscribeToUDSEvents() {
        console.log('[RankingView] 📡 _subscribeToUDSEvents()');
        
        // UDS 초기화 완료 이벤트
        this._eventSubscriptions.push(
            eventBus.on(UnifiedDataStore.EVENTS.INITIALIZED, (event) => {
                console.log('[RankingView] 📥 UDS INITIALIZED event received');
                this._handleUDSInitialized(event);
            }),
            
            // 개별 설비 업데이트
            eventBus.on(UnifiedDataStore.EVENTS.EQUIPMENT_UPDATED, (event) => {
                this._handleUDSEquipmentUpdate(event);
            }),
            
            // 배치 업데이트 완료
            eventBus.on(UnifiedDataStore.EVENTS.BATCH_UPDATED, (event) => {
                this._handleUDSBatchUpdate(event);
            }),
            
            // UDS 통계 변경
            eventBus.on(UnifiedDataStore.EVENTS.STATS_UPDATED, (event) => {
                this._handleUDSStatsUpdate(event);
            })
        );
        
        console.log('[RankingView] ✅ UDS 이벤트 구독 완료');
    }
    
    /**
     * 🆕 v1.5.0: UDS 초기화 완료 처리
     * @private
     * @param {Object} event - { equipments, stats, loadTime, totalCount }
     */
    _handleUDSInitialized(event) {
        console.log(`[RankingView] 📊 UDS 초기화 완료 - ${event.totalCount}개 설비`);
        
        this._udsInitialized = true;
        
        // RankingDataManager가 이미 initializeFromUDS를 호출했으므로
        // 여기서는 UI 렌더링만 처리
        this._renderLaneData();
        
        // 통계 업데이트
        this._updateStats();
        
        // 빈 상태 해제
        this.setEmpty(false);
        this.setLoading(false);
        
        console.log('[RankingView] ✅ UDS 데이터 렌더링 완료');
    }
    
    /**
     * 🆕 v1.5.0: UDS 설비 업데이트 처리
     * @private
     * @param {Object} event - { frontendId, changes, equipment, prevStatus }
     */
    _handleUDSEquipmentUpdate(event) {
        const { frontendId, changes, equipment } = event;
        
        if (!this._isVisible) return;
        
        // RankingDataManager가 레인 할당을 처리하므로
        // 여기서는 카드 업데이트만 수행
        this._updateCardFromUDS(frontendId, equipment);
    }
    
    /**
     * 🆕 v1.5.0: UDS 배치 업데이트 처리
     * @private
     * @param {Object} event - { count, timestamp }
     */
    _handleUDSBatchUpdate(event) {
        console.log(`[RankingView] 📦 배치 업데이트: ${event.count}개 변경`);
        
        // 전체 레인 데이터 다시 렌더링
        if (this._isVisible) {
            this._updateStats();
        }
    }
    
    /**
     * 🆕 v1.5.0: UDS 통계 업데이트 처리
     * @private
     * @param {Object} event - { stats, changed }
     */
    _handleUDSStatsUpdate(event) {
        // 통계 바 업데이트는 _updateStats()에서 처리
        this._updateStats();
    }
    
    /**
     * 🆕 v1.5.0: 레인 데이터 렌더링
     * RankingDataManager의 데이터를 레인 컴포넌트에 반영
     * @private
     */
    _renderLaneData() {
        if (!this._rankingDataManager) return;
        
        console.log('[RankingView] 🔄 _renderLaneData()');
        
		this._cardsMap.clear();
        // 기존 레인 클리어
        this._lanes.forEach(lane => {
            lane.clearCards();
        });
        
        // RankingDataManager에서 레인별 데이터 가져오기
        const allLanes = this._rankingDataManager.getAllLanes();
        
        for (const [laneId, equipments] of allLanes) {
            const lane = this._lanes.get(laneId);
            if (!lane) continue;
            
            // 설비 카드 추가
            for (const equipment of equipments) {
                this._addCardToLane(lane, equipment);
            }
        }
        
        // 통계 업데이트
        this._updateStats();
        
        console.log('[RankingView] ✅ 레인 데이터 렌더링 완료');
    }
    
    /**
     * 🆕 v1.5.0: 레인에 카드 추가
     * 🔄 v1.6.0: cardsMap 등록 추가
     * @private
     * @param {RankingLane} lane - 레인 컴포넌트
     * @param {Object} equipment - 설비 데이터
     */
    _addCardToLane(lane, equipment) {
        // RankingDataManager 형식 → EquipmentCard 형식 변환
        const cardData = {
            equipmentId: equipment.equipmentId,
            frontendId: equipment.frontendId,
            equipmentName: equipment.equipmentName || equipment.frontendId,
            status: equipment.status,
            occurredAt: equipment.occurredAt,
            alarmCode: equipment.alarmCode,
            alarmMessage: equipment.alarmMessage,
            alarmRepeatCount: equipment.alarmRepeatCount,
            productionCount: equipment.productionCount,
            targetCount: equipment.targetCount,
            tactTime: equipment.tactTime,
            lineName: equipment.lineName,
            lotStartTime: equipment.lotInfo?.startedAtUtc
        };
        
        const card = lane.addCard(cardData);
        
        // 🆕 v1.6.0: 카드 인스턴스를 cardsMap에 등록
        if (card && equipment.frontendId) {
            this._cardsMap.set(equipment.frontendId, card);
        }
        
        return card;
    }
    
    /**
     * 🆕 v1.5.0: UDS 데이터로 카드 업데이트
     * @private
     * @param {string} frontendId - Frontend ID
     * @param {Object} equipment - 설비 데이터
     */
    _updateCardFromUDS(frontendId, equipment) {
        if (!equipment) return;
        
        const laneId = equipment.laneId;
        if (!laneId) return;
        
        const lane = this._lanes.get(laneId);
        if (!lane) return;
        
        // 카드 데이터 변환
        const cardData = {
            equipmentId: equipment.equipmentId,
            frontendId: equipment.frontendId,
            equipmentName: equipment.equipmentName || equipment.frontendId,
            status: equipment.status,
            occurredAt: equipment.occurredAt,
            alarmCode: equipment.alarmCode,
            alarmMessage: equipment.alarmMessage,
            productionCount: equipment.productionCount,
            targetCount: equipment.targetCount,
            tactTime: equipment.tactTime
        };
        
        // 기존 카드 업데이트
        lane.updateCard(frontendId, cardData);
    }
    
    /**
     * 🆕 v1.5.0: 3D View 선택 동기화
     * @private
     * @param {Object} event - { frontendId, source, equipment }
     */
    _sync3DViewSelection(event) {
        const { frontendId, source, equipment } = event;
        
        if (!frontendId || source === 'ranking-view') return;
        
        console.log(`[RankingView] 🔗 3D View 선택 동기화: ${frontendId}`);
        
        // 이전 선택 해제
        this._clearSelection();
        
        // 새 선택 설정
        this._selectedEquipmentId = frontendId;
        
        // 해당 카드 찾아서 선택 상태로 변경
        this._lanes.forEach(lane => {
            const card = lane.getCard(frontendId);
            if (card) {
                card.setSelected(true);
                
                // 해당 레인으로 스크롤
                lane.scrollToTop();
            }
        });
    }
    
    /**
     * 🆕 v1.5.0: 설비 하이라이트 처리
     * @private
     * @param {Object} event - { frontendId, isHighlighted }
     */
    _handleEquipmentHighlight(event) {
        const { frontendId, isHighlighted } = event;
        
        if (!frontendId) return;
        
        // 해당 카드 찾아서 하이라이트
        this._lanes.forEach(lane => {
            const card = lane.getCard(frontendId);
            if (card && typeof card.setHighlighted === 'function') {
                card.setHighlighted(isHighlighted);
            }
        });
    }
    
    /**
     * 🆕 v1.5.0: 데이터 새로고침 처리
     * @private
     * @param {Object} event - { totalCount, laneStats }
     */
    _handleDataRefreshed(event) {
        console.log(`[RankingView] 🔄 데이터 새로고침: ${event.totalCount}개 설비`);
        
        if (this._isVisible) {
        	this._updateStats();  
        }
    }
    
    /**
     * 🆕 v1.7.1: 설비 레인 이동 처리 (Ghost 버그 수정)
     * 
     * 🐛 BugFix: 레인 이동 시 _cards Map 동기화 추가
     *   - ranking-view-test.html과 동일한 로직 적용
     *   - 애니메이션 완료 후 fromLane._cards.delete() + toLane._cards.set()
     * 
     * @private
     * @param {Object} event
     */
    async _handleEquipmentMoved(event) {
        const { moved } = event;
        
        if (!this._isVisible || !moved || moved.length === 0) return;
        
        console.log(`[RankingView] 🚀 설비 레인 이동: ${moved.length}개`);
        
        // 1. 같은 레인으로 이동하는 설비들 그룹화
        const movesByLane = this._groupMovesByTargetLane(moved);
        
        // 2. 레인별로 처리
        for (const [toLaneId, moves] of Object.entries(movesByLane)) {
            // 2-1. 복수 설비 삽입 위치 일괄 계산
            const equipments = moves.map(m => m.equipment);
            
            let insertInfos;
            if (this._rankingDataManager && this._rankingDataManager.calculateBatchInsertIndices) {
                insertInfos = this._rankingDataManager.calculateBatchInsertIndices(toLaneId, equipments);
            } else {
                // Fallback: 모두 0번 인덱스
                insertInfos = equipments.map(eq => ({ equipment: eq, targetIndex: 0 }));
            }
            
            // 2-2. 각 설비 애니메이션 및 업데이트
            for (const { equipment, targetIndex } of insertInfos) {
                const move = moves.find(m => 
                    (m.equipment?.frontendId || m.equipmentId) === (equipment.frontendId || equipment.equipmentId)
                );
                if (!move) continue;
                
                const { equipmentId, fromLane } = move;
                const frontendId = equipment.frontendId || equipmentId;
                
                // 새 데이터 준비 (상태 변경 반영)
                const newData = this._prepareUpdatedData(equipment, toLaneId);
                
                // 애니메이션 + UI 업데이트
                if (this._animationManager && fromLane && fromLane !== toLaneId) {
                    try {
                        // ═══════════════════════════════════════════════════════
                        // 🐛 v1.7.1 Fix: _cards Map 동기화 (테스트 코드와 동일)
                        // ═══════════════════════════════════════════════════════
                        const fromLaneComponent = this._lanes.get(fromLane);
                        const toLaneComponent = this._lanes.get(toLaneId);
                        const card = this._cardsMap.get(frontendId);
                        
                        await this._animationManager.animateLaneChange(
                            frontendId,
                            fromLane,
                            toLaneId,
                            {
                                targetIndex,
                                newData,
                                onComplete: (element, data) => {
                                    this._updateCardUI(frontendId, data);
                                }
                            }
                        );
                        
                        // ✅ 핵심 수정: 애니메이션 완료 후 _cards Map 동기화
                        if (fromLaneComponent && toLaneComponent && card) {
                            fromLaneComponent._cards.delete(frontendId);
                            toLaneComponent._cards.set(frontendId, card);
                            fromLaneComponent._updateEmptyState();
                            fromLaneComponent._updateStats();
                            toLaneComponent._updateEmptyState();
                            toLaneComponent._updateStats();
                        }
                        
                    } catch (error) {
                        console.warn(`[RankingView] ⚠️ 애니메이션 실패, fallback 처리:`, error);
                        this._moveCardWithoutAnimation(fromLane, toLaneId, equipmentId, equipment);
                    }
                } else {
                    // AnimationManager 없거나 같은 레인 내 이동
                    this._moveCardWithoutAnimation(fromLane, toLaneId, equipmentId, equipment);
                }
            }
        }
        
        // 3. 레인 통계 업데이트
        this._updateStats();
    }
    
    /**
     * 🆕 v1.7.0: 이동 설비를 목표 레인별로 그룹화
     * @private
     * @param {Array} moves - 이동 정보 배열
     * @returns {Object} { [toLaneId]: [moves] }
     */
    _groupMovesByTargetLane(moves) {
        return moves.reduce((groups, move) => {
            const lane = move.toLane;
            if (!lane) return groups;
            if (!groups[lane]) groups[lane] = [];
            groups[lane].push(move);
            return groups;
        }, {});
    }
    
    /**
     * 🆕 v1.7.0: 레인 이동에 따른 데이터 준비
     * @private
     * @param {Object} equipment - 설비 데이터
     * @param {string} toLaneId - 목표 레인 ID
     * @returns {Object} 업데이트된 설비 데이터
     */
    _prepareUpdatedData(equipment, toLaneId) {
        // 레인별 상태 매핑
        const laneStatusMap = {
            'remote': 'REMOTE',
            'sudden-stop': 'SUDDENSTOP',
            'stop': 'STOP',
            'run': 'RUN',
            'idle': 'IDLE',
            'wait': 'WAIT'
        };
        
        const newStatus = laneStatusMap[toLaneId] || equipment.status;
        
        return {
            ...equipment,
            status: newStatus,
            occurredAt: equipment.occurredAt || new Date().toISOString(),  // Duration 리셋
            // alarmCode는 레인에 따라 처리
            alarmCode: (toLaneId === 'run' || toLaneId === 'idle' || toLaneId === 'wait') 
                ? null 
                : equipment.alarmCode,
            alarmMessage: (toLaneId === 'run' || toLaneId === 'idle' || toLaneId === 'wait')
                ? null
                : equipment.alarmMessage
        };
    }
    
    /**
     * 🆕 v1.7.0: 카드 UI 업데이트
     * @private
     * @param {string} frontendId - 설비 Frontend ID
     * @param {Object} newData - 새 설비 데이터
     */
    _updateCardUI(frontendId, newData) {
        if (!newData) return;
        
        const card = this._cardsMap.get(frontendId);
        if (card && card.updateStatus) {
            card.updateStatus(newData, { resetDuration: false });
            console.log(`[RankingView] 🔄 카드 UI 업데이트 완료: ${frontendId}`);
        }
    }
    
    /**
     * 🆕 v1.6.0: 애니메이션 없이 카드 이동 (Fallback)
     * @private
     */
    _moveCardWithoutAnimation(fromLane, toLane, equipmentId, equipment) {
        // 이전 레인에서 제거
        if (fromLane) {
            const fromLaneComponent = this._lanes.get(fromLane);
            if (fromLaneComponent) {
                fromLaneComponent.removeCard(equipmentId);
            }
            // cardsMap에서도 제거
            this._cardsMap.delete(equipmentId);
        }
        
        // 새 레인에 추가
        if (toLane && equipment) {
            const toLaneComponent = this._lanes.get(toLane);
            if (toLaneComponent) {
                this._addCardToLane(toLaneComponent, equipment);
            }
        }
    }
    
    /**
     * 🆕 v1.5.0: 순위 업데이트 처리
     * @private
     * @param {Object} event - { rankings, timestamp }
     */
	_handleRankingsUpdate(event) {
	    // 🐛 v1.7.2: Ghost 방지 - 전체 재렌더링 대신 통계만 업데이트
	    // 개별 카드 이동은 EQUIPMENT_MOVED 이벤트에서 처리됨
	    if (this._isVisible) {
	        this._updateStats();
	    }
	}
    
    /**
     * 🆕 v1.5.0: 통계 이벤트로 업데이트
     * @private
     * @param {Object} event - { stats }
     */
    _updateStatsFromEvent(event) {
        this._updateStats();
    }
    
    /**
     * 🆕 v1.3.1: Dev Mode 감지
     * @private
     * @returns {boolean}
     */
    _detectDevMode() {
        // 방법 1: URL 파라미터
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('dev') === 'true' || urlParams.get('devmode') === 'true') {
            console.log('[RankingView] 🧪 Dev Mode 감지 (URL 파라미터)');
            return true;
        }
        
        // 방법 2: DOM에서 DEV MODE 버튼 존재 확인
        const devModeButton = document.querySelector('[data-dev-mode]') || 
                              document.querySelector('.dev-mode-btn') ||
                              document.querySelector('#dev-mode-toggle');
        if (devModeButton && devModeButton.classList.contains('active')) {
            console.log('[RankingView] 🧪 Dev Mode 감지 (버튼 활성화)');
            return true;
        }
        
        // 방법 3: 전역 플래그
        if (window.IS_DEV_MODE === true || window.devMode === true) {
            console.log('[RankingView] 🧪 Dev Mode 감지 (전역 플래그)');
            return true;
        }
        
        // 방법 4: localStorage
        if (localStorage.getItem('devMode') === 'true') {
            console.log('[RankingView] 🧪 Dev Mode 감지 (localStorage)');
            return true;
        }
        
        return false;
    }
    
    /**
     * DOM 구조 생성
     * @private
     */
    _createDOM() {
        console.log('[RankingView] 🔨 _createDOM()');
        
        // Main container
        this.element = document.createElement('div');
        this.element.classList.add(RankingView.CSS.BLOCK);
        this.element.classList.add(RankingView.CSS.HIDDEN);
        this.element.classList.add(RankingView.CSS.LEGACY_HIDDEN);
        
        // 🆕 v1.4.0: Header
        this._headerElement = this._createHeader();
        this.element.appendChild(this._headerElement);
        
        // Lanes container
        this._lanesContainer = document.createElement('div');
        this._lanesContainer.classList.add(RankingView.CSS.LANES_CONTAINER);
        
        // 🆕 v1.4.0: Stats Bar
        this._statsBar = this._createStatsBar();
        
        // Loading state
        this._loadingElement = this._createLoadingElement();
        
        // Empty state
        this._emptyElement = this._createEmptyElement();
        
        // Assemble
        this.element.appendChild(this._lanesContainer);
        this.element.appendChild(this._statsBar);
        this.element.appendChild(this._loadingElement);
        this.element.appendChild(this._emptyElement);
        
        // Append to container
        this._container.appendChild(this.element);
    }
    
    /**
     * 🆕 v1.4.0: 헤더 생성
     * @private
     * @returns {HTMLElement}
     */
    _createHeader() {
        const header = document.createElement('div');
        header.classList.add(RankingView.CSS.HEADER);
        
        // Title
        const title = document.createElement('h2');
        title.classList.add(RankingView.CSS.TITLE);
        title.textContent = 'Equipment Ranking';
        header.appendChild(title);
        
        // Controls
        const controls = document.createElement('div');
        controls.classList.add(RankingView.CSS.CONTROLS);
        
        // Custom Lane Controls
        if (this._enableCustomLanes) {
            const customControls = this._createCustomLaneControls();
            controls.appendChild(customControls);
        }
        
        header.appendChild(controls);
        
        return header;
    }
    
    /**
     * 🆕 v1.4.0: Custom 레인 컨트롤 생성
     * @private
     * @returns {HTMLElement}
     */
    _createCustomLaneControls() {
        const container = document.createElement('div');
        container.classList.add(RankingView.CSS.CUSTOM_LANE_CONTROLS);
        
        // 콤보박스
        const select = document.createElement('select');
        select.innerHTML = `
            <option value="">Custom 레인 추가...</option>
            ${CUSTOM_FILTER_OPTIONS.map(opt => 
                `<option value="${opt.value}">${opt.icon} ${opt.label}</option>`
            ).join('')}
        `;
        container.appendChild(select);
        
        // 추가 버튼
        const addBtn = document.createElement('button');
        addBtn.classList.add('u-btn', 'u-btn--sm', 'u-btn--primary');
        addBtn.textContent = '추가';
        addBtn.disabled = true;
        container.appendChild(addBtn);
        
        // 이벤트
        select.addEventListener('change', (e) => {
            const canAdd = e.target.value && this._customLanes.size < RankingView.CONFIG.MAX_CUSTOM_LANES;
            addBtn.disabled = !canAdd;
        });
        
        addBtn.addEventListener('click', () => {
            if (select.value) {
                this.addCustomLane(select.value);
                select.value = '';
                addBtn.disabled = true;
            }
        });
        
        this._customLaneSelect = select;
        this._customLaneAddBtn = addBtn;
        
        return container;
    }
    
    /**
     * 🆕 v1.4.0: 통계 바 생성
     * @private
     * @returns {HTMLElement}
     */
    _createStatsBar() {
        const statsBar = document.createElement('div');
        statsBar.classList.add(RankingView.CSS.STATS_BAR);
        
        statsBar.innerHTML = `
            <span class="${RankingView.CSS.STAT}">
                <span class="${RankingView.CSS.STAT_LABEL}">Total:</span>
                <span class="${RankingView.CSS.STAT_VALUE}" data-stat="total">0</span>
            </span>
            <span class="${RankingView.CSS.STAT} ${RankingView.CSS.STAT}--danger">
                <span class="${RankingView.CSS.STAT_LABEL}">Urgent:</span>
                <span class="${RankingView.CSS.STAT_VALUE}" data-stat="urgent">0</span>
            </span>
            <span class="${RankingView.CSS.STAT} ${RankingView.CSS.STAT}--warning">
                <span class="${RankingView.CSS.STAT_LABEL}">Warning:</span>
                <span class="${RankingView.CSS.STAT_VALUE}" data-stat="warning">0</span>
            </span>
        `;
        
        return statsBar;
    }
    
    /**
     * 로딩 상태 요소 생성
     * @private
     * @returns {HTMLElement}
     */
    _createLoadingElement() {
        const loading = document.createElement('div');
        loading.classList.add(RankingView.CSS.LOADING);
        
        const spinner = document.createElement('div');
        spinner.classList.add(RankingView.CSS.LOADING_SPINNER);
        
        const text = document.createElement('div');
        text.classList.add(RankingView.CSS.LOADING_TEXT);
        text.textContent = '데이터를 불러오는 중...';
        
        loading.appendChild(spinner);
        loading.appendChild(text);
        
        return loading;
    }
    
    /**
     * 빈 상태 요소 생성
     * @private
     * @returns {HTMLElement}
     */
    _createEmptyElement() {
        const empty = document.createElement('div');
        empty.classList.add(RankingView.CSS.EMPTY);
        
        const icon = document.createElement('div');
        icon.classList.add(RankingView.CSS.EMPTY_ICON);
        icon.textContent = '📭';
        
        const title = document.createElement('div');
        title.classList.add(RankingView.CSS.EMPTY_TITLE);
        title.textContent = '표시할 설비가 없습니다';
        
        const message = document.createElement('div');
        message.classList.add(RankingView.CSS.EMPTY_MESSAGE);
        message.textContent = '모니터링 데이터를 수신하면 설비가 표시됩니다.';
        
        empty.appendChild(icon);
        empty.appendChild(title);
        empty.appendChild(message);
        
        return empty;
    }
    
    /**
     * 6개 레인 생성 (Phase 2: RankingLane 컴포넌트 사용)
     * @private
     */
    _createLanes() {
        console.log('[RankingView] 🏗️ _createLanes() - 6개 레인 생성 (RankingLane 컴포넌트)');
        
        LANE_CONFIG.forEach(config => {
            // RankingLane 컴포넌트 생성
            const lane = new RankingLane(config);
            
            // DOM에 추가
            this._lanesContainer.appendChild(lane.element);
            
            // 레인 참조 저장
            this._lanes.set(config.id, lane);
        });
        
        console.log(`[RankingView] ✅ ${this._lanes.size}개 레인 생성 완료`);
    }
    
    /**
     * 🆕 v1.3.0: LaneManager 생성
     * @private
     */
    _createLaneManager() {
        console.log('[RankingView] 🎯 _createLaneManager() - LaneManager 생성');
        
        this._laneManager = new LaneManager({
            lanes: this._lanes,
            onCardSelect: (data) => this._handleLaneManagerCardSelect(data)
        });
        
        console.log('[RankingView] ✅ LaneManager 생성 완료');
    }
    
    /**
     * 이벤트 리스너 설정
     * @private
     */
    _setupEventListeners() {
        console.log('[RankingView] 🔗 _setupEventListeners()');
        
        // Bind handlers for cleanup
        this._boundHandlers.onKeyDown = this._handleKeyDown.bind(this);
        this._boundHandlers.onResize = this._handleResize.bind(this);
        this._boundHandlers.onEquipmentSelect = this._handleEquipmentSelect.bind(this);
        
        // DOM Events
        document.addEventListener('keydown', this._boundHandlers.onKeyDown);
        window.addEventListener('resize', this._boundHandlers.onResize);
        
        // EventBus Subscriptions
        this._eventSubscriptions.push(
            // Ranking View 토글
            eventBus.on('ranking:show', () => this.show()),
            eventBus.on('ranking:hide', () => this.hide()),
            eventBus.on('submenu:ranking-view:activate', () => this.show()),
            eventBus.on('submenu:ranking-view:deactivate', () => this.hide()),
            
            // 설비 선택 이벤트 (Phase 2: Drawer 연동)
            eventBus.on('equipment:select', this._boundHandlers.onEquipmentSelect),
            
            // WebSocket 데이터 이벤트 (Phase 3에서 확장)
            eventBus.on('websocket:equipment:status', (data) => this._handleStatusChange(data)),
            
            // 🆕 v1.3.0: 레인 포커스 이벤트 (KeyboardManager에서 발행)
            eventBus.on('ranking:lane:focus', (data) => {
                if (this._laneManager && data.laneIndex !== undefined) {
                    this._laneManager.focusLane(data.laneIndex);
                }
            }),
            eventBus.on('ranking:lane:previous', () => {
                if (this._laneManager) this._laneManager.focusPreviousLane();
            }),
            eventBus.on('ranking:lane:next', () => {
                if (this._laneManager) this._laneManager.focusNextLane();
            }),
            eventBus.on('ranking:card:previous', () => {
                if (this._laneManager) this._laneManager.selectPreviousCard();
            }),
            eventBus.on('ranking:card:next', () => {
                if (this._laneManager) this._laneManager.selectNextCard();
            }),
            eventBus.on('ranking:card:detail', () => {
                if (this._laneManager) this._laneManager.showSelectedCardDetail();
            }),
            
            // 🆕 v1.4.0: Custom 레인 이벤트
            eventBus.on('customLane:added', () => {
                this._updateCustomLaneButtonState();
                this._updateStats();
            }),
            eventBus.on('customLane:removed', () => {
                this._updateCustomLaneButtonState();
                this._updateStats();
            })
        );
        
        console.log('[RankingView] ✅ 이벤트 리스너 설정 완료');
    }
    
    // =========================================
    // 🆕 v1.3.1: CameraNavigator 제어 (강화)
    // =========================================
    
    /**
     * CameraNavigator 가시성 설정 (강화 버전)
     * @private
     * @param {boolean} visible - 표시 여부
     */
    _setCameraNavigatorVisible(visible) {
        console.log(`[RankingView] 📐 CameraNavigator ${visible ? '표시' : '숨김'} 시도...`);
        
        let success = false;
        
        // 방법 1: 전역 window.cameraNavigator 사용
        if (window.cameraNavigator?.setVisible) {
            window.cameraNavigator.setVisible(visible);
            console.log(`[RankingView] ✅ CameraNavigator ${visible ? '표시' : '숨김'} (window.cameraNavigator)`);
            success = true;
        }
        
        // 방법 2: window.services.cameraNavigator 사용
        if (window.services?.cameraNavigator?.setVisible) {
            window.services.cameraNavigator.setVisible(visible);
            console.log(`[RankingView] ✅ CameraNavigator ${visible ? '표시' : '숨김'} (services.cameraNavigator)`);
            success = true;
        }
        
        // 방법 3: window.services.scene.cameraNavigator 사용
        if (window.services?.scene?.cameraNavigator?.setVisible) {
            window.services.scene.cameraNavigator.setVisible(visible);
            console.log(`[RankingView] ✅ CameraNavigator ${visible ? '표시' : '숨김'} (services.scene.cameraNavigator)`);
            success = true;
        }
        
        // 방법 4: DOM 직접 접근 (폴백) - ID로 찾기
        const navigatorById = document.getElementById('camera-navigator');
        if (navigatorById) {
            navigatorById.style.display = visible ? 'block' : 'none';
            console.log(`[RankingView] ✅ CameraNavigator ${visible ? '표시' : '숨김'} (DOM #camera-navigator)`);
            success = true;
        }
        
        // 방법 5: DOM 직접 접근 - 클래스로 찾기
        const navigatorByClass = document.querySelector('.camera-navigator');
        if (navigatorByClass) {
            navigatorByClass.style.display = visible ? 'block' : 'none';
            console.log(`[RankingView] ✅ CameraNavigator ${visible ? '표시' : '숨김'} (DOM .camera-navigator)`);
            success = true;
        }
        
        // 방법 6: SVG 네비게이터 찾기 (CameraNavigator의 실제 구조 기반)
        const svgNavigator = document.querySelector('#camera-navigator svg');
        if (svgNavigator && svgNavigator.parentElement) {
            svgNavigator.parentElement.style.display = visible ? 'block' : 'none';
            console.log(`[RankingView] ✅ CameraNavigator ${visible ? '표시' : '숨김'} (SVG parent)`);
            success = true;
        }
        
        if (!success) {
            console.log('[RankingView] ⚠️ CameraNavigator를 찾을 수 없음 - 모든 방법 실패');
        }
    }
    
    /**
     * CameraNavigator 현재 가시성 상태 확인
     * @private
     * @returns {boolean}
     */
    _getCameraNavigatorVisible() {
        // 전역 접근
        if (window.cameraNavigator?.navContainer) {
            return window.cameraNavigator.navContainer.style.display !== 'none';
        }
        
        if (window.services?.cameraNavigator?.navContainer) {
            return window.services.cameraNavigator.navContainer.style.display !== 'none';
        }
        
        if (window.services?.scene?.cameraNavigator?.navContainer) {
            return window.services.scene.cameraNavigator.navContainer.style.display !== 'none';
        }
        
        // DOM 직접 접근
        const navigatorEl = document.getElementById('camera-navigator');
        if (navigatorEl) {
            return navigatorEl.style.display !== 'none';
        }
        
        return true; // 기본값
    }
    
    /**
     * 🔧 v1.8.0: 통계 바 업데이트 + StatusBar 동기화 이벤트 발행
     * @private
     */
    _updateStats() {
        if (!this._statsBar) return;
        
        let total = 0;
        let urgent = 0;  // Critical + Danger (Remote, SuddenStop)
        let warning = 0; // Stop, Idle
        
        // 🆕 v1.8.0: 레인별 개수 객체 (StatusBar 동기화용)
        const laneStats = {};
        
        // 모든 레인의 카드를 순회하며 긴급도 집계
        this._lanes.forEach((lane, laneId) => {
            const count = lane.count;
            total += count;
            
            // 🆕 레인별 개수 저장
            laneStats[laneId] = count;
            
            // 레인 타입에 따른 긴급도 분류
            if (laneId === 'remote' || laneId === 'sudden-stop') {
                urgent += count;
            } else if (laneId === 'stop' || laneId === 'idle') {
                warning += count;
            }
        });
        
        // Custom 레인도 집계
        this._customLanes.forEach(customLane => {
            if (customLane.lane) {
                const cards = customLane.lane.getAllCards();
                cards.forEach(card => {
                    total++;
                    const urgencyLevel = card.getUrgencyLevel ? card.getUrgencyLevel() : null;
                    if (urgencyLevel === 'critical' || urgencyLevel === 'danger') {
                        urgent++;
                    } else if (urgencyLevel === 'warning') {
                        warning++;
                    }
                });
            }
        });
        
        // 🆕 v1.8.0: Disconnected 개수 계산 (매핑 안 된 설비)
        laneStats.disconnected = this._getDisconnectedCount(total);
        
        // DOM 업데이트
        const totalEl = this._statsBar.querySelector('[data-stat="total"]');
        const urgentEl = this._statsBar.querySelector('[data-stat="urgent"]');
        const warningEl = this._statsBar.querySelector('[data-stat="warning"]');
        
        if (totalEl) totalEl.textContent = total;
        if (urgentEl) urgentEl.textContent = urgent;
        if (warningEl) warningEl.textContent = warning;
        
        // 🆕 v1.8.0: StatusBar에 레인 통계 이벤트 발행
        eventBus.emit('ranking:lane-stats-updated', laneStats);
    }

    /**
     * 🆕 v1.8.0: Disconnected 개수 계산
     * @private
     * @param {number} inLaneCount - 레인에 있는 설비 수
     * @returns {number}
     */
    _getDisconnectedCount(inLaneCount) {
        // 전체 설비 수 가져오기 (UDS 또는 기본값)
        let totalEquipment = 117; // 기본값
        
        if (this._rankingDataManager) {
            totalEquipment = this._rankingDataManager.getTotalCount() || totalEquipment;
        } else if (unifiedDataStore?.isInitialized()) {
            totalEquipment = unifiedDataStore.getStats()?.totalMapped || totalEquipment;
        }
        
        return Math.max(0, totalEquipment - inLaneCount);
    }
    
    /**
     * 🆕 v1.4.0: Custom 레인 추가 버튼 상태 업데이트
     * @private
     */
    _updateCustomLaneButtonState() {
        if (this._customLaneAddBtn && this._customLaneSelect) {
            const canAdd = this._customLaneSelect.value && 
                          this._customLanes.size < RankingView.CONFIG.MAX_CUSTOM_LANES;
            this._customLaneAddBtn.disabled = !canAdd;
        }
    }
    
    // =========================================
    // Public Methods
    // =========================================
    
    /**
     * Ranking View 표시
     */
    show() {
        if (this._isVisible) {
            console.log('[RankingView] ⚠️ 이미 표시 중');
            return;
        }
        
        console.log('[RankingView] 👁️ show()');
        
        // 🆕 v1.3.1: CameraNavigator 현재 상태 저장 후 숨김 (강화)
        this._cameraNavigatorWasVisible = this._getCameraNavigatorVisible();
        this._setCameraNavigatorVisible(false);
        
        this.element.classList.remove(RankingView.CSS.HIDDEN);
        this.element.classList.remove(RankingView.CSS.LEGACY_HIDDEN);
        this.element.classList.add(RankingView.CSS.ACTIVE);
        this.element.classList.add(RankingView.CSS.LEGACY_ACTIVE);
        
        this._isVisible = true;
        
        // 🆕 v1.3.0: LaneManager 활성화
        if (this._laneManager) {
            this._laneManager.activate();
        }
        
        // 🆕 v1.5.0: UDS 모드인 경우 데이터 렌더링
        if (this._useUDS && this._udsInitialized) {
            this._renderLaneData();
        } else {
            // 🆕 v1.3.1: 데이터 확인 및 Dev Mode 처리
            this._checkDataAndLoadTestData();
        }
        
        // 🆕 v1.4.0: 통계 업데이트
        this._updateStats();
        
        // Emit event
        eventBus.emit('ranking:shown');
        
        console.log('[RankingView] ✅ 표시됨');
    }
    
    /**
     * 🆕 v1.3.1: 데이터 확인 후 필요시 테스트 데이터 로드
     * @private
     */
    _checkDataAndLoadTestData() {
        // 모든 레인의 카드 수 확인
        let totalCards = 0;
        this._lanes.forEach(lane => {
            totalCards += lane.count;
        });
        
        console.log(`[RankingView] 📊 현재 카드 수: ${totalCards}`);
        
        if (totalCards === 0) {
            // 🆕 Dev Mode 재감지 (동적으로 변경될 수 있음)
            this._isDevMode = this._detectDevMode();
            
            // Backend 연결 확인
            const isBackendConnected = this._checkBackendConnection();
            
            if (!isBackendConnected || this._isDevMode) {
                console.log('[RankingView] 🧪 테스트 데이터 자동 로드 (Dev Mode 또는 Backend 미연결)');
                this.addTestData();
            } else {
                // Backend 연결됨 but 데이터 없음
                this.setEmpty(true);
            }
        } else {
            this.setEmpty(false);
        }
    }
    
    /**
     * 🆕 v1.3.1: Backend 연결 상태 확인
     * @private
     * @returns {boolean}
     */
    _checkBackendConnection() {
        // 🆕 v1.5.0: UDS 연결 상태 확인
        if (this._useUDS && unifiedDataStore.isInitialized()) {
            return true;
        }
        
        // WebSocket 연결 상태 확인
        if (this._webSocketClient?.isConnected) {
            return this._webSocketClient.isConnected();
        }
        
        // 전역 연결 상태 확인
        if (window.webSocketClient?.isConnected) {
            return window.webSocketClient.isConnected();
        }
        
        // ConnectionIndicator 상태 확인
        const connectionIndicator = document.querySelector('.connection-indicator');
        if (connectionIndicator?.classList.contains('connected')) {
            return true;
        }
        
        // 기본: 연결 안 됨으로 가정
        return false;
    }
    
    /**
     * Ranking View 숨김
     */
    hide() {
        if (!this._isVisible) {
            console.log('[RankingView] ⚠️ 이미 숨김 상태');
            return;
        }
        
        console.log('[RankingView] 🙈 hide()');
        
        this.element.classList.add(RankingView.CSS.HIDDEN);
        this.element.classList.add(RankingView.CSS.LEGACY_HIDDEN);
        this.element.classList.remove(RankingView.CSS.ACTIVE);
        this.element.classList.remove(RankingView.CSS.LEGACY_ACTIVE);
        
        this._isVisible = false;
        
        // 🆕 v1.3.0: LaneManager 비활성화
        if (this._laneManager) {
            this._laneManager.deactivate();
        }
        
        // 🆕 v1.3.1: CameraNavigator 복원 (강화)
        // 3D View가 활성화된 경우에만 표시
        if (this._cameraNavigatorWasVisible) {
            const threejsContainer = document.getElementById('threejs-container');
            const is3DViewActive = threejsContainer && 
                                   (threejsContainer.classList.contains('active') || 
                                    threejsContainer.style.display !== 'none');
            
            if (is3DViewActive) {
                // 약간의 딜레이 후 표시 (전환 애니메이션 고려)
                setTimeout(() => {
                    this._setCameraNavigatorVisible(true);
                }, 100);
            }
        }
        
        // Emit event
        eventBus.emit('ranking:hidden');
        
        console.log('[RankingView] ✅ 숨겨짐');
    }
    
    /**
     * 표시/숨김 토글
     */
    toggle() {
        if (this._isVisible) {
            this.hide();
        } else {
            this.show();
        }
    }
    
    /**
     * 로딩 상태 설정
     * @param {boolean} isLoading
     */
    setLoading(isLoading) {
        console.log(`[RankingView] ⏳ setLoading(${isLoading})`);
        
        this._isLoading = isLoading;
        
        if (isLoading) {
            this.element.classList.add(RankingView.CSS.LOADING_STATE);
            this.element.classList.add(RankingView.CSS.LEGACY_LOADING);
        } else {
            this.element.classList.remove(RankingView.CSS.LOADING_STATE);
            this.element.classList.remove(RankingView.CSS.LEGACY_LOADING);
        }
    }
    
    /**
     * 빈 상태 설정
     * @param {boolean} isEmpty
     */
    setEmpty(isEmpty) {
        console.log(`[RankingView] 📭 setEmpty(${isEmpty})`);
        
        if (isEmpty) {
            this.element.classList.add(RankingView.CSS.EMPTY_STATE);
        } else {
            this.element.classList.remove(RankingView.CSS.EMPTY_STATE);
        }
    }
    
    /**
     * 설비 카드 추가
     * @param {string} laneId - 레인 ID
     * @param {Object} data - 설비 데이터
     * @returns {EquipmentCard|null}
     */
addEquipment(laneId, data) {
    const lane = this._lanes.get(laneId);
    if (!lane) {
        console.warn(`[RankingView] ⚠️ 레인을 찾을 수 없음: ${laneId}`);
        return null;
    }
    
    const card = lane.addCard(data);
    
    // ✅ 수정: equipmentKey 변수 정의 추가
    const equipmentKey = data.frontendId || data.equipmentId;
    this._cardsMap.set(equipmentKey, card);
    
    this.setEmpty(false);
    
    // 🆕 v1.4.0: 통계 업데이트
    this._updateStats();
    
    console.log(`[RankingView] ➕ 설비 추가: ${equipmentKey} → ${laneId}`);
    return card;
}
    
    /**
     * 설비 카드 제거
     * @param {string} laneId - 레인 ID
     * @param {string} equipmentId - 설비 ID
     */
    removeEquipment(laneId, equipmentId) {
        const lane = this._lanes.get(laneId);
        if (lane) {
            lane.removeCard(equipmentId);
            console.log(`[RankingView] ➖ 설비 제거: ${equipmentId} from ${laneId}`);
            
            // 전체 빈 상태 확인
            this._checkEmpty();
            
            // 🆕 v1.4.0: 통계 업데이트
            this._updateStats();
        }
    }
    
    /**
     * 설비 카드 업데이트
     * @param {string} laneId - 레인 ID
     * @param {string} equipmentId - 설비 ID
     * @param {Object} newData - 새 데이터
     */
    updateEquipment(laneId, equipmentId, newData) {
        const lane = this._lanes.get(laneId);
        if (lane) {
            lane.updateCard(equipmentId, newData);
            
            // 🆕 v1.4.0: 통계 업데이트
            this._updateStats();
        }
    }
    
    /**
     * 🆕 v1.4.0: Custom 레인 추가
     * @param {string} filterType - 필터 타입
     * @param {Object} [filterConfig] - 필터 설정
     * @returns {RankingLane|null}
     */
    addCustomLane(filterType, filterConfig = {}) {
        if (this._customLanes.size >= RankingView.CONFIG.MAX_CUSTOM_LANES) {
            console.warn(`[RankingView] ⚠️ Custom 레인 최대 개수(${RankingView.CONFIG.MAX_CUSTOM_LANES}) 초과`);
            return null;
        }
        
        const filterOption = CUSTOM_FILTER_OPTIONS.find(opt => opt.value === filterType);
        if (!filterOption) {
            console.warn(`[RankingView] ⚠️ 알 수 없는 필터 타입: ${filterType}`);
            return null;
        }
        
        // Custom 레인 ID 생성
        const customId = `custom-${filterType}-${Date.now()}`;
        
        // 레인 설정
        const laneConfig = {
            id: customId,
            name: filterConfig.name || filterOption.label,
            icon: filterOption.icon,
            description: `Custom: ${filterOption.label}`,
            sortKey: filterConfig.sortKey || 'duration',
            sortOrder: filterConfig.sortOrder || 'desc',
            isCustom: true,
            filterType: filterType,
            filterConfig: filterConfig
        };
        
        // RankingLane 생성
        const lane = new RankingLane(laneConfig);
        
        // DOM에 추가
        this._lanesContainer.appendChild(lane.element);
        
        // Custom 레인 정보 저장
        this._customLanes.set(customId, {
            ...laneConfig,
            lane: lane
        });
        
        // 이벤트 발행
        eventBus.emit('customLane:added', {
            laneId: customId,
            filterType: filterType,
            config: laneConfig
        });
        
        console.log(`[RankingView] ✅ Custom 레인 추가: ${customId}`);
        
        return lane;
    }
    
    /**
     * 🆕 v1.4.0: Custom 레인 삭제
     * @param {string} laneId - 레인 ID
     */
    removeCustomLane(laneId) {
        if (!this._customLanes.has(laneId)) {
            console.warn(`[RankingView] ⚠️ Custom 레인을 찾을 수 없음: ${laneId}`);
            return;
        }
        
        const customLane = this._customLanes.get(laneId);
        
        // 레인 dispose
        if (customLane.lane) {
            customLane.lane.dispose();
        }
        
        // 저장소에서 제거
        this._customLanes.delete(laneId);
        
        // 이벤트 발행
        eventBus.emit('customLane:removed', { laneId });
        
        console.log(`[RankingView] 🗑️ Custom 레인 삭제: ${laneId}`);
    }
    
    /**
     * 🆕 v1.4.0: Custom 레인 활성화 설정
     * @param {boolean} enabled - 활성화 여부
     */
    setCustomLanesEnabled(enabled) {
        this._enableCustomLanes = enabled;
        
        // UI 업데이트
        const customControls = this.element?.querySelector(`.${RankingView.CSS.CUSTOM_LANE_CONTROLS}`);
        if (customControls) {
            customControls.style.display = enabled ? 'flex' : 'none';
        }
    }
    
    /**
     * 레인 가져오기
     * @param {string} laneId
     * @returns {RankingLane|undefined}
     */
    getLane(laneId) {
        return this._lanes.get(laneId);
    }
    
    /**
     * 모든 레인 가져오기
     * @returns {Map<string, RankingLane>}
     */
    getAllLanes() {
        return new Map(this._lanes);
    }
    
    /**
     * 🆕 v1.3.0: LaneManager 인스턴스 가져오기
     * @returns {LaneManager|null}
     */
    getLaneManager() {
        return this._laneManager;
    }
    
    /**
     * 🆕 v1.5.0: RankingDataManager 인스턴스 가져오기
     * @returns {RankingDataManager|null}
     */
    getRankingDataManager() {
        return this._rankingDataManager;
    }
    
    /**
     * 가시성 상태
     * @returns {boolean}
     */
    get isVisible() {
        return this._isVisible;
    }
    
    /**
     * 선택된 설비 ID
     * @returns {string|null}
     */
    get selectedEquipmentId() {
        return this._selectedEquipmentId;
    }
    
    /**
     * 리소스 정리 및 제거
     */
    dispose() {
        console.log('[RankingView] 🗑️ dispose() - 정리 시작...');
        
        // 1. DOM 이벤트 리스너 제거
        document.removeEventListener('keydown', this._boundHandlers.onKeyDown);
        window.removeEventListener('resize', this._boundHandlers.onResize);
        
        // 2. EventBus 구독 해제
        this._eventSubscriptions.forEach(unsubscribe => {
            if (typeof unsubscribe === 'function') {
                unsubscribe();
            }
        });
        this._eventSubscriptions = [];
        
        // 3. 🆕 v1.3.0: LaneManager 정리
        if (this._laneManager) {
            this._laneManager.dispose();
            this._laneManager = null;
        }
        
        // 🆕 v1.6.0: AnimationManager 정리
        if (this._animationManager) {
            this._animationManager.dispose();
            this._animationManager = null;
        }
        
        // 🆕 v1.6.0: cardsMap 정리
        this._cardsMap.clear();

        // 4. 🆕 v1.5.0: RankingDataManager 정리
        if (this._rankingDataManager) {
            this._rankingDataManager.dispose();
            this._rankingDataManager = null;
        }
        
        // 5. 레인 컴포넌트 정리
        this._lanes.forEach((lane, id) => {
            lane.dispose();
        });
        this._lanes.clear();
        
        // 6. 🆕 v1.4.0: Custom 레인 정리
        this._customLanes.forEach((customLane, id) => {
            if (customLane.lane) {
                customLane.lane.dispose();
            }
        });
        this._customLanes.clear();
        
        // 7. 🆕 v1.2.0: CameraNavigator 가시성 복원
        if (this._cameraNavigatorWasVisible) {
            this._setCameraNavigatorVisible(true);
        }
        
        // 8. DOM 요소 제거
        this.element?.remove();
        
        // 9. 참조 해제
        this.element = null;
        this._headerElement = null;
        this._lanesContainer = null;
        this._statsBar = null;
        this._loadingElement = null;
        this._emptyElement = null;
        this._customLaneSelect = null;
        this._customLaneAddBtn = null;
        this._boundHandlers = {};
        this._isInitialized = false;
        
        console.log('[RankingView] ✅ dispose 완료');
    }
    
    // =========================================
    // Event Handlers
    // =========================================
    
    /**
     * 설비 선택 이벤트 처리 (Phase 2: Drawer 연동)
     * @private
     */
    _handleEquipmentSelect(data) {
        if (!this._isVisible) return;
        
        const { equipmentId, frontendId, source } = data;
        
        console.log(`[RankingView] 🎯 설비 선택: ${frontendId || equipmentId} (source: ${source})`);
        
        // 이전 선택 해제
        this._clearSelection();
        
        // 새 선택 설정
        this._selectedEquipmentId = equipmentId || frontendId;
        
        // 카드 선택 상태 업데이트
        this._lanes.forEach(lane => {
            const card = lane.getCard(this._selectedEquipmentId);
            if (card) {
                card.setSelected(true);
            }
        });
        
        // Equipment Info Drawer에 데이터 전달 (source가 ranking-view인 경우)
        if (source === 'ranking-view' && data.cardData) {
            // EquipmentInfoPanel.show()에 전달할 데이터 포맷
            const panelData = {
                id: frontendId,
                frontendId: frontendId,
                equipmentId: equipmentId,
                ...data.cardData
            };
            
            // Drawer 표시를 위한 이벤트 발행
            eventBus.emit('equipment:detail:show', panelData);
        }
        
        // 🆕 v1.5.0: 3D View 동기화 (source가 ranking-view일 때만)
        if (source === 'ranking-view' && this._rankingDataManager) {
            this._rankingDataManager.syncWith3DView(frontendId || equipmentId);
        }
    }
    
    /**
     * 🆕 v1.3.0: LaneManager에서 카드 선택 시 호출
     * @private
     */
    _handleLaneManagerCardSelect(data) {
        const { equipmentId, frontendId, laneId, cardIndex } = data;
        
        console.log(`[RankingView] 🎯 LaneManager 카드 선택: ${frontendId} (lane: ${laneId}, index: ${cardIndex})`);
        
        // 선택 상태 업데이트
        this._selectedEquipmentId = equipmentId || frontendId;
        
        // 🆕 v1.5.0: 3D View 동기화
        if (this._rankingDataManager) {
            this._rankingDataManager.syncWith3DView(frontendId || equipmentId);
        }
    }
    
    /**
     * 선택 해제
     * @private
     */
    _clearSelection() {
        this._lanes.forEach(lane => {
            lane.getAllCards().forEach(card => {
                card.setSelected(false);
            });
        });
        this._selectedEquipmentId = null;
    }
    
    /**
     * 키보드 이벤트 처리
     * @private
     */
    _handleKeyDown(event) {
        if (!this._isVisible) return;
        
        // 🆕 v1.3.0: LaneManager가 있으면 대부분의 키 처리를 위임
        // LaneManager가 없는 경우에만 직접 처리
        if (this._laneManager && this._laneManager.isActive) {
            // LaneManager가 활성화되어 있으면 키 이벤트는 
            // KeyboardManager → LaneManager 경로로 처리됨
            // 여기서는 Escape만 추가 처리
            if (event.key === 'Escape') {
                event.preventDefault();
                eventBus.emit('ranking:escape');
                this.hide();
                eventBus.emit('mode:3d-view');
            }
            return;
        }
        
        // LaneManager가 없는 경우 (폴백) - 기존 로직 유지
        const laneIds = Array.from(this._lanes.keys());
        
        switch (event.key) {
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
                // 레인 포커스 이동
                event.preventDefault();
                this._focusLane(parseInt(event.key) - 1);
                break;
                
            case 'ArrowLeft':
                // 이전 레인으로 이동
                event.preventDefault();
                this._focusLane(Math.max(0, this._focusedLaneIndex - 1));
                break;
                
            case 'ArrowRight':
                // 다음 레인으로 이동
                event.preventDefault();
                this._focusLane(Math.min(laneIds.length - 1, this._focusedLaneIndex + 1));
                break;
                
            case 'ArrowUp':
                // 현재 레인에서 이전 카드 선택
                event.preventDefault();
                break;
                
            case 'ArrowDown':
                // 현재 레인에서 다음 카드 선택
                event.preventDefault();
                break;
                
            case 'Enter':
                // 선택된 카드 상세 보기
                event.preventDefault();
                if (this._selectedEquipmentId) {
                    eventBus.emit('equipment:detail:show', {
                        id: this._selectedEquipmentId,
                        frontendId: this._selectedEquipmentId
                    });
                }
                break;
                
            case 'Escape':
                // 3D View로 복귀
                event.preventDefault();
                eventBus.emit('ranking:escape');
                this.hide();
                eventBus.emit('mode:3d-view');
                break;
        }
    }
    
    /**
     * 레인 포커스 (폴백용 - LaneManager가 없는 경우)
     * @private
     * @param {number} index
     */
    _focusLane(index) {
        const laneIds = Array.from(this._lanes.keys());
        if (index < 0 || index >= laneIds.length) return;
        
        // 모든 레인에서 포커스 제거
        this._lanes.forEach(lane => {
            lane.setFocused(false);
        });
        
        // 선택된 레인에 포커스 추가
        const laneId = laneIds[index];
        const lane = this._lanes.get(laneId);
        lane.setFocused(true);
        
        this._focusedLaneIndex = index;
        
        console.log(`[RankingView] 🎯 레인 포커스: ${laneId} (index: ${index})`);
    }
    
    /**
     * 상태 변경 이벤트 처리 (Phase 3에서 확장)
     * @private
     */
    _handleStatusChange(data) {
        // Phase 3에서 구현 예정
        // 레인 간 이동 로직
        
        // 🆕 v1.4.0: 통계 업데이트
        this._updateStats();
    }
    
    /**
     * 리사이즈 이벤트 처리
     * @private
     */
    _handleResize() {
        // Phase 7에서 반응형 최적화 구현
    }
    
    /**
     * 전체 빈 상태 확인
     * @private
     */
    _checkEmpty() {
        let totalCount = 0;
        this._lanes.forEach(lane => {
            totalCount += lane.count;
        });
        
        this.setEmpty(totalCount === 0);
    }
    
    // =========================================
    // Debug Methods
    // =========================================
    
    /**
     * 디버그 정보 출력
     */
    debug() {
        console.group('[RankingView] Debug Info (v1.5.0)');
        console.log('isVisible:', this._isVisible);
        console.log('isInitialized:', this._isInitialized);
        console.log('isLoading:', this._isLoading);
        console.log('isDevMode:', this._isDevMode);
        console.log('useUDS:', this._useUDS);
        console.log('udsInitialized:', this._udsInitialized);
        console.log('enableCustomLanes:', this._enableCustomLanes);
        console.log('selectedEquipmentId:', this._selectedEquipmentId);
        console.log('focusedLaneIndex:', this._focusedLaneIndex);
        console.log('cameraNavigatorWasVisible:', this._cameraNavigatorWasVisible);
        console.log('laneManager:', this._laneManager ? 'connected' : 'null');
        console.log('rankingDataManager:', this._rankingDataManager ? 'connected' : 'null');
        console.log('레인 수:', this._lanes.size);
        console.log('Custom 레인 수:', this._customLanes.size);
        console.log('레인 목록:');
        this._lanes.forEach((lane, id) => {
            console.log(`  ${id}: ${lane.count} cards`);
        });
        console.log('Custom 레인 목록:');
        this._customLanes.forEach((customLane, id) => {
            console.log(`  ${id}: ${customLane.lane?.count || 0} cards`);
        });
        if (this._laneManager) {
            console.log('--- LaneManager Debug ---');
            this._laneManager.debug();
        }
        if (this._rankingDataManager) {
            console.log('--- RankingDataManager Debug ---');
            console.log('UDS Mode:', this._rankingDataManager.isUDSMode());
            console.log('UDS Initialized:', this._rankingDataManager.isUDSInitialized());
            console.log('Total Equipments:', this._rankingDataManager.getTotalCount());
        }
        console.groupEnd();
    }
    
    /**
     * 테스트 데이터 추가 (개발용)
     */
    addTestData() {
        console.log('[RankingView] 🧪 테스트 데이터 추가...');
        
        // Remote 레인 테스트 데이터
        this.addEquipment('remote', {
            equipmentId: 'EQ001',
            frontendId: 'EQ-17-01',
            equipmentName: '설비 17-01',
            status: 'SUDDENSTOP',
            occurredAt: new Date(Date.now() - 20 * 60 * 1000).toISOString(), // 20분 전
            alarmCode: 10047,
            alarmMessage: 'BLADE BROKEN',
            alarmRepeatCount: 3,
            productionCount: 45,
            targetCount: 100
        });
        
        this.addEquipment('remote', {
            equipmentId: 'EQ008',
            frontendId: 'EQ-18-02',
            equipmentName: '설비 18-02',
            status: 'SUDDENSTOP',
            occurredAt: new Date(Date.now() - 35 * 60 * 1000).toISOString(), // 35분 전
            alarmCode: 20015,
            alarmMessage: 'MOTOR OVERHEAT',
            alarmRepeatCount: 5,
            productionCount: 12,
            targetCount: 100
        });
        
        // Sudden Stop 레인 테스트 데이터
        this.addEquipment('sudden-stop', {
            equipmentId: 'EQ002',
            frontendId: 'EQ-17-02',
            equipmentName: '설비 17-02',
            status: 'SUDDENSTOP',
            occurredAt: new Date(Date.now() - 8 * 60 * 1000).toISOString(), // 8분 전
            alarmCode: 1234,
            alarmMessage: 'SENSOR ERROR',
            productionCount: 72,
            targetCount: 100
        });
        
        this.addEquipment('sudden-stop', {
            equipmentId: 'EQ009',
            frontendId: 'EQ-19-01',
            equipmentName: '설비 19-01',
            status: 'SUDDENSTOP',
            occurredAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(), // 15분 전
            alarmCode: 5678,
            alarmMessage: 'VACUUM LOSS',
            productionCount: 55,
            targetCount: 100
        });
        
        // Run 레인 테스트 데이터
        this.addEquipment('run', {
            equipmentId: 'EQ003',
            frontendId: 'EQ-17-03',
            equipmentName: '설비 17-03',
            status: 'RUN',
            occurredAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2시간 전
            productionCount: 95,
            targetCount: 100,
            lotStartTime: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString()
        });
        
        this.addEquipment('run', {
            equipmentId: 'EQ004',
            frontendId: 'EQ-17-04',
            equipmentName: '설비 17-04',
            status: 'RUN',
            occurredAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30분 전
            productionCount: 67,
            targetCount: 100,
            lotStartTime: new Date(Date.now() - 45 * 60 * 1000).toISOString()
        });
        
        this.addEquipment('run', {
            equipmentId: 'EQ010',
            frontendId: 'EQ-20-01',
            equipmentName: '설비 20-01',
            status: 'RUN',
            occurredAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(), // 1시간 전
            productionCount: 82,
            targetCount: 100,
            lotStartTime: new Date(Date.now() - 50 * 60 * 1000).toISOString()
        });
        
        // Stop 레인 테스트 데이터
        this.addEquipment('stop', {
            equipmentId: 'EQ005',
            frontendId: 'EQ-17-05',
            equipmentName: '설비 17-05',
            status: 'STOP',
            occurredAt: new Date(Date.now() - 12 * 60 * 1000).toISOString(), // 12분 전
            productionCount: 33,
            targetCount: 100
        });
        
        this.addEquipment('stop', {
            equipmentId: 'EQ011',
            frontendId: 'EQ-21-01',
            equipmentName: '설비 21-01',
            status: 'STOP',
            occurredAt: new Date(Date.now() - 45 * 60 * 1000).toISOString(), // 45분 전
            productionCount: 88,
            targetCount: 100
        });
        
        // Idle 레인 테스트 데이터
        this.addEquipment('idle', {
            equipmentId: 'EQ006',
            frontendId: 'EQ-17-06',
            equipmentName: '설비 17-06',
            status: 'IDLE',
            occurredAt: new Date(Date.now() - 3 * 60 * 1000).toISOString(), // 3분 전
            productionCount: 88,
            targetCount: 100
        });
        
        this.addEquipment('idle', {
            equipmentId: 'EQ012',
            frontendId: 'EQ-22-01',
            equipmentName: '설비 22-01',
            status: 'IDLE',
            occurredAt: new Date(Date.now() - 7 * 60 * 1000).toISOString(), // 7분 전
            productionCount: 65,
            targetCount: 100
        });
        
        // Wait 레인 테스트 데이터
        this.addEquipment('wait', {
            equipmentId: 'EQ007',
            frontendId: 'EQ-17-07',
            equipmentName: '설비 17-07',
            status: 'WAIT',
            occurredAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(), // 25분 전
            productionCount: 0,
            targetCount: 0
        });
        
        this.addEquipment('wait', {
            equipmentId: 'EQ013',
            frontendId: 'EQ-23-01',
            equipmentName: '설비 23-01',
            status: 'WAIT',
            occurredAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(), // 1시간 전
            productionCount: 0,
            targetCount: 0
        });
        
        // 🆕 v1.4.0: 통계 업데이트
        this._updateStats();
        
        console.log('[RankingView] ✅ 테스트 데이터 추가 완료 (총 13개 설비)');
    }
    
    /**
     * 🆕 v1.3.1: 모든 데이터 초기화
     */
    clearAllData() {
        console.log('[RankingView] 🗑️ 모든 데이터 초기화...');
        
        this._lanes.forEach(lane => {
            lane.clearCards();
        });
        
        this._checkEmpty();
        
        // 🆕 v1.4.0: 통계 업데이트
        this._updateStats();
        
        console.log('[RankingView] ✅ 데이터 초기화 완료');
    }
}

// 전역 노출 (디버깅용)
if (typeof window !== 'undefined') {
    window.RankingView = RankingView;
}