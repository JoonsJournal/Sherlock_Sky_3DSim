/**
 * SiteSelectionPanel.js
 * 사이트 선택 및 연결 관리 패널
 * 
 * @version 3.0.0
 * @description
 * - 🆕 v3.0.0: Phase 4 CSS Integration
 *   - CSS 클래스명 static 상수 정의
 *   - BEM 네이밍 규칙 적용
 *   - classList API 통일
 * - v2.1.0: BasePanel 상속 적용, 인라인 스타일 제거
 * 
 * 📁 위치: frontend/threejs_viewer/src/ui/SiteSelectionPanel.js
 * 수정일: 2026-01-15
 */

import { BasePanel } from '../core/base/BasePanel.js';
import { connectionStore } from '../services/stores/ConnectionStore.js';
import { toast } from './common/Toast.js';

/**
 * SiteSelectionPanel
 * 사이트 연결 관리 패널
 */
export class SiteSelectionPanel extends BasePanel {
    // =========================================================================
    // CSS 클래스 상수 (Phase 4)
    // =========================================================================
    
    /**
     * BEM 클래스명 상수
     * @static
     */
    static CSS = {
        // Block
        BLOCK: 'site-selection-panel',
        
        // Elements
        HEADER: 'site-selection-panel__header',
        ACTIONS: 'site-selection-panel__actions',
        LIST: 'site-selection-panel__list',
        FOOTER: 'site-selection-panel__footer',
        
        // Site Item
        SITE_ITEM: 'site-item',
        SITE_ITEM_SELECTED: 'site-item--selected',
        SITE_ITEM_CONNECTED: 'site-item--connected',
        SITE_ITEM_CONNECTING: 'site-item--connecting',
        SITE_ITEM_FAILED: 'site-item--failed',
        
        SITE_CHECKBOX: 'site-item__checkbox',
        SITE_INFO: 'site-item__info',
        SITE_NAME: 'site-item__name',
        SITE_REGION: 'site-item__region',
        SITE_META: 'site-item__meta',
        SITE_STATUS: 'site-item__status',
        
        // Buttons
        BTN_CONNECT: 'site-selection-panel__connect-btn',
        BTN_CONNECT_DISABLED: 'site-selection-panel__connect-btn--disabled',
        BTN_DISCONNECT: 'site-item__disconnect-btn',
        BTN_RETRY: 'site-item__retry-btn',
        
        // States
        LOADING: 'site-selection-panel--loading',
        NO_SITES: 'site-selection-panel__no-sites',
        
        // Legacy alias
        LEGACY_SELECTED: 'selected',
        LEGACY_CONNECTED: 'connected'
    };
    
    /**
     * Utility 클래스 상수
     * @static
     */
    static UTIL = {
        HIDDEN: 'u-hidden',
        FLEX: 'u-flex',
        FLEX_CENTER: 'u-flex-center',
        GLASS: 'u-glass'
    };
    
    /**
     * @param {Object} options
     * @param {Object} options.connectionService - 연결 서비스
     */
    constructor(options = {}) {
        super({
            ...options,
            title: '🔍 Site Connection',
            collapsible: false,
            className: `connection-panel ${SiteSelectionPanel.CSS.BLOCK}`
        });
        
        this.connectionService = options.connectionService;
        this.profiles = [];
        this.selectedSites = [];
        this.siteStatus = {};
        this.isConnecting = false;
    }
    
    /**
     * 헤더 렌더링 오버라이드
     */
    renderHeader() {
        const autoConnect = connectionStore.getState().autoConnect;
        
        return `
            <div class="panel-header ${SiteSelectionPanel.CSS.HEADER}">
                <h3>🔍 Site Connection</h3>
                <div class="panel-actions ${SiteSelectionPanel.CSS.ACTIONS}">
                    <label class="auto-connect-label">
                        <input type="checkbox" id="auto-connect-checkbox" ${autoConnect ? 'checked' : ''}>
                        <span>Auto Connect</span>
                    </label>
                    <button class="btn-icon" id="select-all-btn" title="Select All">☑️</button>
                    <button class="btn-icon" id="deselect-all-btn" title="Deselect All">☐</button>
                </div>
            </div>
        `;
    }
    
    /**
     * 패널 내용 렌더링
     */
    renderContent() {
        return `
            <div class="site-list ${SiteSelectionPanel.CSS.LIST}" id="site-list">
                <div class="loading-spinner-small"></div>
                <span class="loading-text">Loading sites...</span>
            </div>
            <div class="panel-footer ${SiteSelectionPanel.CSS.FOOTER}">
                <div class="selection-info">
                    <span id="selection-count">Selected: 0</span>
                </div>
                <button class="${SiteSelectionPanel.CSS.BTN_CONNECT} btn-connect" id="connect-btn" disabled>
                    🔌 Connect
                </button>
            </div>
        `;
    }
    
    /**
     * 이벤트 리스너 등록
     */
    attachEventListeners() {
        // 전체 선택
        const selectAllBtn = this.$('#select-all-btn');
        if (selectAllBtn) {
            this.addDomListener(selectAllBtn, 'click', () => this._selectAll());
        }

        // 전체 해제
        const deselectAllBtn = this.$('#deselect-all-btn');
        if (deselectAllBtn) {
            this.addDomListener(deselectAllBtn, 'click', () => this._deselectAll());
        }

        // 연결 버튼
        const connectBtn = this.$('#connect-btn');
        if (connectBtn) {
            this.addDomListener(connectBtn, 'click', () => this._connectSelected());
        }

        // 자동 연결 체크박스
        const autoConnectCheckbox = this.$('#auto-connect-checkbox');
        if (autoConnectCheckbox) {
            this.addDomListener(autoConnectCheckbox, 'change', (e) => {
                connectionStore.setAutoConnect(e.target.checked);
                if (e.target.checked) {
                    toast.info('Auto-connect enabled');
                }
            });
        }
    }
    
    /**
     * 프로필 로드
     */
    async loadProfiles() {
        try {
            this.profiles = await this.connectionService.getProfiles();
            await this._loadStatus();
            this._renderSites();
            
            // 마지막 연결 사이트 자동 선택
            const lastConnected = connectionStore.getState().lastConnectedSites;
            if (lastConnected.length > 0) {
                this.selectedSites = [lastConnected[0]];
                this._updateSelectionUI();
            }
        } catch (error) {
            console.error('Failed to load profiles:', error);
            toast.error('Failed to load site profiles');
        }
    }
    
    /**
     * 상태 로드
     */
    async _loadStatus() {
        try {
            const statusList = await this.connectionService.getStatus();
            this.siteStatus = {};
            statusList.forEach(status => {
                this.siteStatus[status.site_id] = status;
            });
        } catch (error) {
            console.error('Failed to load status:', error);
        }
    }
    
    /**
     * 사이트 목록 렌더링
     */
    _renderSites() {
        const siteList = this.$('#site-list');
        if (!siteList) return;
        
        if (this.profiles.length === 0) {
            siteList.innerHTML = `<div class="${SiteSelectionPanel.CSS.NO_SITES} no-sites">No sites available</div>`;
            return;
        }

        // 우선순위 순으로 정렬
        const sortedProfiles = [...this.profiles].sort((a, b) => b.priority - a.priority);

        siteList.innerHTML = sortedProfiles.map(profile => {
            const status = this.siteStatus[profile.id] || {};
            const isConnected = status.status === 'connected';
            const isConnecting = status.status === 'connecting';
            const isFailed = status.status === 'failed';
            const isSelected = this.selectedSites.includes(profile.id);

            // BEM 클래스 결정
            const itemClasses = [
                SiteSelectionPanel.CSS.SITE_ITEM,
                'site-item', // Legacy
                isSelected ? SiteSelectionPanel.CSS.SITE_ITEM_SELECTED : '',
                isSelected ? SiteSelectionPanel.CSS.LEGACY_SELECTED : '',
                isConnected ? SiteSelectionPanel.CSS.SITE_ITEM_CONNECTED : '',
                isConnected ? SiteSelectionPanel.CSS.LEGACY_CONNECTED : '',
                isConnecting ? SiteSelectionPanel.CSS.SITE_ITEM_CONNECTING : '',
                isFailed ? SiteSelectionPanel.CSS.SITE_ITEM_FAILED : ''
            ].filter(Boolean).join(' ');

            return `
                <div class="${itemClasses}" data-site-id="${profile.id}">
                    <div class="${SiteSelectionPanel.CSS.SITE_CHECKBOX} site-checkbox">
                        <input type="checkbox" 
                               id="site-${profile.id}" 
                               ${isSelected ? 'checked' : ''}
                               ${isConnecting ? 'disabled' : ''}>
                    </div>
                    <div class="${SiteSelectionPanel.CSS.SITE_INFO} site-info">
                        <div class="site-main">
                            <span class="${SiteSelectionPanel.CSS.SITE_NAME} site-name">${profile.display_name}</span>
                            <span class="${SiteSelectionPanel.CSS.SITE_REGION} site-region">${profile.region}</span>
                        </div>
                        <div class="${SiteSelectionPanel.CSS.SITE_META} site-meta">
                            ${status.last_connected ? `
                                <span class="last-connected">Last: ${new Date(status.last_connected).toLocaleString()}</span>
                            ` : ''}
                            ${status.response_time_ms ? `
                                <span class="response-time">${status.response_time_ms}ms</span>
                            ` : ''}
                        </div>
                    </div>
                    <div class="${SiteSelectionPanel.CSS.SITE_STATUS} site-status">
                        ${isConnecting ? `
                            <div class="loading-spinner-small"></div>
                        ` : isConnected ? `
                            <span class="status-icon">✅</span>
                            <button class="${SiteSelectionPanel.CSS.BTN_DISCONNECT} btn-disconnect" data-site-id="${profile.id}">Disconnect</button>
                        ` : isFailed ? `
                            <span class="status-icon">❌</span>
                            <button class="${SiteSelectionPanel.CSS.BTN_RETRY} btn-retry" data-site-id="${profile.id}">Retry</button>
                        ` : `
                            <span class="status-icon">⚪</span>
                        `}
                    </div>
                </div>
            `;
        }).join('');

        // 체크박스 이벤트 등록
        siteList.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                const siteId = e.target.id.replace('site-', '');
                this._toggleSite(siteId);
            });
        });

        // 연결 해제 버튼 이벤트
        siteList.querySelectorAll(`.${SiteSelectionPanel.CSS.BTN_DISCONNECT}, .btn-disconnect`).forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const siteId = btn.dataset.siteId;
                this._disconnectSite(siteId);
            });
        });

        // 재시도 버튼 이벤트
        siteList.querySelectorAll(`.${SiteSelectionPanel.CSS.BTN_RETRY}, .btn-retry`).forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const siteId = btn.dataset.siteId;
                this._retrySite(siteId);
            });
        });
    }
    
    /**
     * 사이트 선택 토글
     */
    _toggleSite(siteId) {
        // Single site만 허용
        if (this.selectedSites.includes(siteId)) {
            this.selectedSites = [];
        } else {
            this.selectedSites = [siteId];
            // 다른 체크박스 해제
            this.element?.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                if (cb.id !== `site-${siteId}`) {
                    cb.checked = false;
                }
            });
        }
        
        connectionStore.setSelectedSites(this.selectedSites);
        this._updateSelectionUI();
        this._renderSites(); // 스타일 업데이트를 위해 재렌더링
    }
    
    /**
     * 전체 선택
     */
    _selectAll() {
        // Single site만 허용하므로 첫 번째만 선택
        if (this.profiles.length > 0) {
            toast.info('Only single site connection is supported');
            this.selectedSites = [this.profiles[0].id];
            this._updateSelectionUI();
            this._renderSites();
        }
    }
    
    /**
     * 전체 해제
     */
    _deselectAll() {
        this.selectedSites = [];
        connectionStore.setSelectedSites(this.selectedSites);
        this._updateSelectionUI();
        this._renderSites();
    }
    
    /**
     * 선택 UI 업데이트
     */
    _updateSelectionUI() {
        const countEl = this.$('#selection-count');
        const connectBtn = this.$('#connect-btn');
        
        if (countEl) {
            countEl.textContent = `Selected: ${this.selectedSites.length}`;
        }
        
        if (connectBtn) {
            const isDisabled = this.selectedSites.length === 0 || this.isConnecting;
            connectBtn.disabled = isDisabled;
            connectBtn.classList.toggle(SiteSelectionPanel.CSS.BTN_CONNECT_DISABLED, isDisabled);
        }
    }
    
    /**
     * 선택된 사이트 연결
     */
    async _connectSelected() {
        if (this.selectedSites.length === 0 || this.isConnecting) return;

        this.isConnecting = true;
        const connectBtn = this.$('#connect-btn');
        if (connectBtn) {
            connectBtn.disabled = true;
            connectBtn.classList.add(SiteSelectionPanel.CSS.BTN_CONNECT_DISABLED);
            connectBtn.textContent = '⏳ Connecting...';
        }

        const siteId = this.selectedSites[0];

        try {
            // 상태 업데이트: connecting
            this.siteStatus[siteId] = { ...this.siteStatus[siteId], status: 'connecting' };
            this._renderSites();

            // 연결 시도
            const result = await this.connectionService.connectToSite(siteId, 30);

            if (result.success) {
                toast.success(`Connected to ${siteId.replace('_', ' ')}`);
                await this._loadStatus();
                this._renderSites();
                
                // 이벤트 발생 (DatabaseListPanel 업데이트용)
                this.container?.dispatchEvent(new CustomEvent('site-connected', {
                    detail: { siteId }
                }));
            } else {
                toast.error(`Failed to connect to ${siteId}`);
                await this._loadStatus();
                this._renderSites();
            }
        } catch (error) {
            console.error('Connection error:', error);
            toast.error(`Error: ${error.message}`);
            this.siteStatus[siteId] = { ...this.siteStatus[siteId], status: 'failed' };
            this._renderSites();
        } finally {
            this.isConnecting = false;
            if (connectBtn) {
                connectBtn.disabled = false;
                connectBtn.classList.remove(SiteSelectionPanel.CSS.BTN_CONNECT_DISABLED);
                connectBtn.textContent = '🔌 Connect';
            }
        }
    }
    
    /**
     * 사이트 연결 해제
     */
    async _disconnectSite(siteId) {
        try {
            await this.connectionService.disconnectFromSite(siteId);
            toast.success(`Disconnected from ${siteId.replace('_', ' ')}`);
            connectionStore.removeConnectedSite(siteId);
            await this._loadStatus();
            this._renderSites();
            
            // 이벤트 발생
            this.container?.dispatchEvent(new CustomEvent('site-disconnected', {
                detail: { siteId }
            }));
        } catch (error) {
            toast.error(`Failed to disconnect: ${error.message}`);
        }
    }
    
    /**
     * 재시도
     */
    async _retrySite(siteId) {
        this.selectedSites = [siteId];
        this._updateSelectionUI();
        this._renderSites();
        await this._connectSelected();
    }
}

export default SiteSelectionPanel;
