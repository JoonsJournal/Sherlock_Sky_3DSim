/**
 * Canvas2DEditor.js (Updated v1.1)
 * ==================
 * Konva.js 기반 2D Layout Editor
 * 
 * 업데이트:
 * - 새로운 JSON 구조 지원 (start/end 객체 형식)
 * - 하위 호환성 유지 (기존 startX/endX 형식)
 * - excludedPositions 배열 지원
 * - 더 나은 에러 처리
 * 
 * 설치 위치: /src/layout_editor/components/Canvas2DEditor.js
 */

class Canvas2DEditor {
    constructor(containerId, options = {}) {
        this.containerId = containerId;
        this.container = document.getElementById(containerId);
        
        if (!this.container) {
            throw new Error(`Container with id "${containerId}" not found`);
        }

        // 기본 설정
        this.config = {
            width: options.width || 1200,
            height: options.height || 800,
            scale: options.scale || 10, // 1m = 10px
            gridSize: options.gridSize || 10, // 10px (1m)
            gridMajorInterval: options.gridMajorInterval || 10, // 100px마다 굵은 선 (10m)
            backgroundColor: options.backgroundColor || '#f5f5f5',
            gridColor: options.gridColor || '#d0d0d0',
            gridMajorColor: options.gridMajorColor || '#a0a0a0'
        };

        // Konva Stage 및 Layers
        this.stage = null;
        this.backgroundLayer = null;
        this.roomLayer = null;
        this.equipmentLayer = null;
        this.uiLayer = null;

        // 현재 로드된 Layout 데이터
        this.currentLayout = null;

        // 초기화
        this.init();
    }

    /**
     * Editor 초기화
     */
    init() {
        console.log('[Canvas2DEditor] Initializing...');
        
        // Konva Stage 생성
        this.stage = new Konva.Stage({
            container: this.containerId,
            width: this.config.width,
            height: this.config.height
        });

        // 4개 Layer 생성
        this.createLayers();

        // 그리드 그리기
        this.drawGrid();

        console.log('[Canvas2DEditor] Initialized successfully');
    }

    /**
     * 4개 Layer 생성
     */
    createLayers() {
        this.backgroundLayer = new Konva.Layer({
            listening: false
        });

        this.roomLayer = new Konva.Layer();
        this.equipmentLayer = new Konva.Layer();
        this.uiLayer = new Konva.Layer();

        this.stage.add(this.backgroundLayer);
        this.stage.add(this.roomLayer);
        this.stage.add(this.equipmentLayer);
        this.stage.add(this.uiLayer);

        console.log('[Canvas2DEditor] 4 Layers created');
    }

    /**
     * 그리드 그리기
     */
    drawGrid() {
        const width = this.config.width;
        const height = this.config.height;
        const gridSize = this.config.gridSize;
        const majorInterval = this.config.gridMajorInterval;

        // 배경색
        const background = new Konva.Rect({
            x: 0,
            y: 0,
            width: width,
            height: height,
            fill: this.config.backgroundColor
        });
        this.backgroundLayer.add(background);

        // 세로 그리드 선
        for (let i = 0; i <= width; i += gridSize) {
            const isMajor = (i % (gridSize * majorInterval)) === 0;
            const line = new Konva.Line({
                points: [i, 0, i, height],
                stroke: isMajor ? this.config.gridMajorColor : this.config.gridColor,
                strokeWidth: isMajor ? 1 : 0.5,
                lineCap: 'round',
                lineJoin: 'round'
            });
            this.backgroundLayer.add(line);
        }

        // 가로 그리드 선
        for (let i = 0; i <= height; i += gridSize) {
            const isMajor = (i % (gridSize * majorInterval)) === 0;
            const line = new Konva.Line({
                points: [0, i, width, i],
                stroke: isMajor ? this.config.gridMajorColor : this.config.gridColor,
                strokeWidth: isMajor ? 1 : 0.5,
                lineCap: 'round',
                lineJoin: 'round'
            });
            this.backgroundLayer.add(line);
        }

        this.backgroundLayer.batchDraw();
        console.log('[Canvas2DEditor] Grid drawn');
    }

    /**
     * Layout 데이터 로드 및 시각화
     */
    loadLayout(layoutData) {
        console.log('[Canvas2DEditor] Loading layout:', layoutData);
        
        this.currentLayout = layoutData;

        // 기존 Layer 클리어
        this.roomLayer.destroyChildren();
        this.equipmentLayer.destroyChildren();
        this.uiLayer.destroyChildren();

        // Room 그리기
        if (layoutData.room) {
            this.drawRoom(layoutData.room);
        }

        // Walls 그리기
        if (layoutData.walls && layoutData.walls.length > 0) {
            layoutData.walls.forEach(wall => this.drawWall(wall));
        }

        // Office 그리기
        if (layoutData.office && layoutData.office.enabled) {
            this.drawOffice(layoutData.office);
        }

        // Partitions 그리기
        if (layoutData.partitions && layoutData.partitions.length > 0) {
            layoutData.partitions.forEach(partition => this.drawPartition(partition));
        }

        // Equipment Arrays 그리기
        if (layoutData.equipmentArrays && layoutData.equipmentArrays.length > 0) {
            layoutData.equipmentArrays.forEach(array => this.drawEquipmentArray(array));
        }

        // Layer 재렌더링
        this.roomLayer.batchDraw();
        this.equipmentLayer.batchDraw();

        console.log('[Canvas2DEditor] Layout loaded successfully');
    }

    /**
     * Room 경계선 그리기
     */
    drawRoom(room) {
        const centerX = this.config.width / 2;
        const centerY = this.config.height / 2;
        const scale = this.config.scale;

        const rect = new Konva.Rect({
            x: centerX - (room.width * scale) / 2,
            y: centerY - (room.depth * scale) / 2,
            width: room.width * scale,
            height: room.depth * scale,
            stroke: '#666666',
            strokeWidth: 2,
            dash: [10, 5],
            listening: false
        });

        this.roomLayer.add(rect);

        // Room 크기 표시
        const label = new Konva.Text({
            x: rect.x() + 10,
            y: rect.y() + 10,
            text: `Room: ${room.width}m x ${room.depth}m`,
            fontSize: 14,
            fontFamily: 'Arial',
            fill: '#666666',
            listening: false
        });

        this.roomLayer.add(label);
    }

    /**
     * Wall 그리기 (새 구조 + 하위 호환성)
     */
    drawWall(wall) {
        const centerX = this.config.width / 2;
        const centerY = this.config.height / 2;
        const scale = this.config.scale;

        // ✅ 새 구조 지원: start/end 객체
        let startX, startZ, endX, endZ;
        
        if (wall.start && wall.end) {
            // 새 구조
            startX = wall.start.x;
            startZ = wall.start.z;
            endX = wall.end.x;
            endZ = wall.end.z;
        } else {
            // 기존 구조 (하위 호환)
            startX = wall.startX;
            startZ = wall.startZ;
            endX = wall.endX;
            endZ = wall.endZ;
        }

        const line = new Konva.Line({
            points: [
                centerX + startX * scale,
                centerY + startZ * scale,
                centerX + endX * scale,
                centerY + endZ * scale
            ],
            stroke: wall.color || '#888888',
            strokeWidth: wall.thickness * scale || 3,
            lineCap: 'square',
            lineJoin: 'miter',
            name: 'wall',
            id: wall.id
        });

        this.roomLayer.add(line);
    }

    /**
     * Office 그리기 (새 구조 + 하위 호환성)
     */
    drawOffice(office) {
        const centerX = this.config.width / 2;
        const centerY = this.config.height / 2;
        const scale = this.config.scale;

        // ✅ 새 구조 지원: position 객체
        let posX, posZ;
        
        if (office.position) {
            posX = office.position.x;
            posZ = office.position.z;
        } else {
            posX = office.positionX || 0;
            posZ = office.positionZ || 0;
        }

        const rect = new Konva.Rect({
            x: centerX + (posX - office.width / 2) * scale,
            y: centerY + (posZ - office.depth / 2) * scale,
            width: office.width * scale,
            height: office.depth * scale,
            fill: office.floorColor || office.color || '#d4e6f1',
            stroke: '#3498db',
            strokeWidth: 2,
            opacity: 0.5,
            name: 'office'
        });

        this.roomLayer.add(rect);

        // Office 라벨
        const label = new Konva.Text({
            x: rect.x() + 5,
            y: rect.y() + 5,
            text: 'Office',
            fontSize: 12,
            fontFamily: 'Arial',
            fill: '#2c3e50',
            listening: false
        });

        this.roomLayer.add(label);
    }

    /**
     * Partition 그리기 (새 구조 + 하위 호환성)
     */
    drawPartition(partition) {
        const centerX = this.config.width / 2;
        const centerY = this.config.height / 2;
        const scale = this.config.scale;

        // ✅ 새 구조 지원
        let startX, startZ, endX, endZ;
        
        if (partition.start && partition.end) {
            startX = partition.start.x;
            startZ = partition.start.z;
            endX = partition.end.x;
            endZ = partition.end.z;
        } else {
            startX = partition.startX;
            startZ = partition.startZ;
            endX = partition.endX;
            endZ = partition.endZ;
        }

        const line = new Konva.Line({
            points: [
                centerX + startX * scale,
                centerY + startZ * scale,
                centerX + endX * scale,
                centerY + endZ * scale
            ],
            stroke: partition.color || '#aaaaaa',
            strokeWidth: partition.thickness * scale || 1,
            opacity: partition.opacity || 0.5,
            lineCap: 'round',
            name: 'partition',
            id: partition.id
        });

        this.roomLayer.add(line);
    }

    /**
     * Equipment Array 그리기 (새 구조 + 하위 호환성)
     */
    drawEquipmentArray(array) {
        console.log('=== drawEquipmentArray 시작 ===');
        console.log('Array config:', array);
        
        const centerX = this.config.width / 2;
        const centerY = this.config.height / 2;
        const scale = this.config.scale;

        // ✅ 새 구조 지원: startPosition 객체
        let startX, startZ;
        
        if (array.startPosition) {
            startX = array.startPosition.x;
            startZ = array.startPosition.z;
        } else {
            startX = array.startX || 0;
            startZ = array.startZ || 0;
        }

        console.log('Start position:', startX, startZ);

        // ✅ excludedPositions를 Set으로 변환 (빠른 조회)
        const excludedSet = new Set();
        if (array.excludedPositions && Array.isArray(array.excludedPositions)) {
            array.excludedPositions.forEach(pos => {
                excludedSet.add(`${pos.row}-${pos.col}`);
            });
        }

        let currentX = startX;
        let currentZ = startZ;
        let equipmentCount = 0;

        for (let row = 0; row < array.rows; row++) {
            currentX = startX;

            for (let col = 0; col < array.cols; col++) {
                // 제외된 위치 체크
                const posKey = `${row}-${col}`;
                if (excludedSet.has(posKey)) {
                    console.log(`Skip position: ${posKey}`);
                    currentX += array.equipmentWidth + array.spacingX;
                    continue;
                }

                // 설비 박스 그리기
                const equipmentId = `EQ-${String(row + 1).padStart(2, '0')}-${String(col + 1).padStart(2, '0')}`;
                
                const equipment = new Konva.Rect({
                    x: centerX + currentX * scale,
                    y: centerY + currentZ * scale,
                    width: array.equipmentWidth * scale,
                    height: array.equipmentDepth * scale,
                    fill: '#4a90e2',
                    stroke: '#2c3e50',
                    strokeWidth: 1,
                    cornerRadius: 2,
                    name: 'equipment',
                    id: equipmentId
                });

                this.equipmentLayer.add(equipment);

                // 설비 ID 라벨
                const label = new Konva.Text({
                    x: equipment.x() + 2,
                    y: equipment.y() + 2,
                    text: equipmentId,
                    fontSize: 8,
                    fontFamily: 'Arial',
                    fill: '#ffffff',
                    listening: false
                });

                this.equipmentLayer.add(label);

                equipmentCount++;

                // 다음 열로 이동
                currentX += array.equipmentWidth + array.spacingX;

                // ✅ 복도 처리 (기존 구조 호환)
                if (array.corridorAfterCol && array.corridorAfterCol.includes(col + 1)) {
                    currentX += array.corridorWidthX || 0;
                }
            }

            // 다음 행으로 이동
            currentZ += array.equipmentDepth + array.spacingZ;

            // ✅ 복도 처리 (기존 구조 호환)
            if (array.corridorAfterRow && array.corridorAfterRow.includes(row + 1)) {
                currentZ += array.corridorWidthZ || 0;
            }
        }

        console.log(`[Canvas2DEditor] Drew ${equipmentCount} equipment units`);
    }

    /**
     * Editor 클리어
     */
    clear() {
        this.roomLayer.destroyChildren();
        this.equipmentLayer.destroyChildren();
        this.uiLayer.destroyChildren();
        
        this.roomLayer.batchDraw();
        this.equipmentLayer.batchDraw();
        this.uiLayer.batchDraw();
        
        this.currentLayout = null;
        
        console.log('[Canvas2DEditor] Cleared');
    }

    /**
     * Editor Destroy
     */
    destroy() {
        if (this.stage) {
            this.stage.destroy();
            this.stage = null;
        }
        
        console.log('[Canvas2DEditor] Destroyed');
    }

    /**
     * 현재 Layout 데이터 가져오기
     */
    getCurrentLayout() {
        return this.currentLayout;
    }

    /**
     * Stage 크기 조정
     */
    resize(width, height) {
        this.stage.width(width);
        this.stage.height(height);
        this.config.width = width;
        this.config.height = height;

        // 그리드 재그리기
        this.backgroundLayer.destroyChildren();
        this.drawGrid();

        console.log(`[Canvas2DEditor] Resized to ${width}x${height}`);
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Canvas2DEditor;
}