/**
 * MonitoringService.js - v3.0.0
 * 실시간 설비 모니터링 서비스
 * 
 * ⭐ v3.0.0: SignalTower 연동 강화
 * - 초기화 흐름 개선 (모든 램프 OFF → 미매핑 DISABLED → REST API로 상태 로드)
 * - 새 매핑 이벤트 처리 (mapping-changed)
 * - SignalTower 미매핑 설비 DISABLED 처리
 * - API URL 수정: /equipment/{frontend_id}/live
 * 
 * 📁 위치: frontend/threejs_viewer/src/services/MonitoringService.js
 */

import { debugLog } from '../core/utils/Config.js';

export class MonitoringService {
    constructor(signalTowerManager, equipmentLoader = null, equipmentEditState = null) {
        this.signalTowerManager = signalTowerManager;
        this.equipmentLoader = equipmentLoader;
        this.equipmentEditState = equipmentEditState;
        
        this.apiBaseUrl = 'http://localhost:8000/api/monitoring';
        this.wsUrl = 'ws://localhost:8000/api/monitoring/stream';
        
        this.ws = null;
        this.isActive = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 3000;
        
        this.statusCache = new Map();
        this.updateQueue = [];
        this.batchInterval = 1000;
        this.batchTimer = null;
        
        // 미연결 설비 색상 옵션
        this.disabledOptions = {
            grayColor: 0x444444  // 어두운 회색 (바닥과 구별)
        };
        
        this.statusPanelElement = null;
        
        this.currentStats = {
            mapped: 0,
            unmapped: 0,
            total: 0,
            rate: 0
        };
        
        // ⭐ v3.0.0: EventBus 참조 (있으면 사용)
        this.eventBus = null;
        
        // ⭐ v3.0.0: 이벤트 핸들러 바인딩 (제거 시 필요)
        this._boundHandleMappingChanged = this.handleMappingChanged.bind(this);
        
        debugLog('MonitoringService initialized (v3.0.0)');
    }
    
    /**
     * 의존성 설정
     */
    setDependencies(equipmentLoader, equipmentEditState, eventBus = null) {
        this.equipmentLoader = equipmentLoader;
        this.equipmentEditState = equipmentEditState;
        this.eventBus = eventBus;
        debugLog('MonitoringService dependencies set');
    }
    
    /**
     * ⭐ v3.0.0: 모니터링 시작 (개선된 흐름)
     */
    async start() {
        if (this.isActive) {
            debugLog('⚠️ Monitoring already active');
            return;
        }
        
        debugLog('🟢 Starting monitoring mode (v3.0.0)...');
        this.isActive = true;
        
        try {
            // ============================================
            // 1️⃣ SignalTower 모든 램프 초기화 (OFF 상태)
            // ============================================
            if (this.signalTowerManager) {
                this.signalTowerManager.initializeAllLights();
                debugLog('🚨 Step 1: SignalTower lights initialized (all OFF)');
            }
            
            // ============================================
            // 2️⃣ 미매핑 설비 처리
            // ============================================
            // 2-1. 설비 모델 회색 처리
            this.applyUnmappedEquipmentStyle();
            debugLog('🌫️ Step 2-1: Unmapped equipment model grayed out');
            
            // 2-2. SignalTower 램프 DISABLED 처리
            this.applyUnmappedSignalTowerStyle();
            debugLog('🌫️ Step 2-2: Unmapped SignalTower lamps disabled');
            
            // ============================================
            // 3️⃣ 통계 패널 표시
            // ============================================
            this.createStatusPanel();
            debugLog('📊 Step 3: Status panel created');
            
            // ============================================
            // 4️⃣ REST API로 초기 상태 로드
            // ============================================
            await this.loadInitialStatus().catch(err => {
                debugLog(`⚠️ Step 4: loadInitialStatus failed: ${err.message}`);
            });
            debugLog('📡 Step 4: Initial status loaded');
            
            // ============================================
            // 5️⃣ WebSocket 연결 + Subscribe
            // ============================================
            this.connectWebSocket();
            debugLog('🔌 Step 5: WebSocket connecting...');
            
            // ============================================
            // 6️⃣ 배치 처리 타이머 시작
            // ============================================
            this.startBatchProcessing();
            debugLog('⏱️ Step 6: Batch processing started');
            
            // ============================================
            // 7️⃣ 이벤트 리스너 등록 (새 매핑 감지)
            // ============================================
            this.registerEventListeners();
            debugLog('📡 Step 7: Event listeners registered');
            
            debugLog('✅ Monitoring mode started successfully (v3.0.0)');
            
        } catch (error) {
            console.error('❌ Failed to start monitoring:', error);
            // 에러가 나도 isActive는 유지 (UI 표시를 위해)
        }
    }
    
    /**
     * 모니터링 중지
     */
    stop() {
        debugLog('🔴 Stopping monitoring mode...');
        this.isActive = false;
        
        // 1. 이벤트 리스너 해제
        this.unregisterEventListeners();
        
        // 2. 비활성화 표시 해제
        this.resetEquipmentStyle();
        
        // 3. 통계 패널 제거
        this.removeStatusPanel();
        
        // 4. WebSocket 연결 종료
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
        
        // 5. 배치 처리 타이머 중지
        if (this.batchTimer) {
            clearInterval(this.batchTimer);
            this.batchTimer = null;
        }
        
        debugLog('✅ Monitoring mode stopped');
    }
    
    // ============================================
    // ⭐ v3.0.0: SignalTower 미매핑 설비 처리
    // ============================================
    
    /**
     * ⭐ v3.0.0: 미매핑 설비의 SignalTower 램프 DISABLED 처리
     */
    applyUnmappedSignalTowerStyle() {
        if (!this.signalTowerManager || !this.equipmentLoader || !this.equipmentEditState) {
            debugLog('⚠️ Dependencies not ready for SignalTower style');
            return;
        }
        
        const equipmentArray = this.equipmentLoader.getAllEquipment();
        const unmappedIds = [];
        const mappedIds = [];
        
        equipmentArray.forEach(equipment => {
            const frontendId = equipment.userData.id;
            const isMapped = this.equipmentEditState.isComplete(frontendId);
            
            if (isMapped) {
                mappedIds.push(frontendId);
            } else {
                unmappedIds.push(frontendId);
            }
        });
        
        // 미매핑 설비 램프 DISABLED
        if (unmappedIds.length > 0) {
            this.signalTowerManager.disableUnmappedEquipment(unmappedIds);
        }
        
        debugLog(`🚨 SignalTower: ${mappedIds.length} mapped, ${unmappedIds.length} disabled`);
    }
    
    // ============================================
    // ⭐ v3.0.0: 이벤트 리스너 (새 매핑 감지)
    // ============================================
    
    /**
     * ⭐ v3.0.0: 이벤트 리스너 등록
     */
    registerEventListeners() {
        // EventBus 사용 (있으면)
        if (this.eventBus) {
            this.eventBus.on('mapping-changed', this._boundHandleMappingChanged);
            this.eventBus.on('mapping-created', this._boundHandleMappingChanged);
            debugLog('📡 EventBus listeners registered');
        }
        
        // DOM CustomEvent도 지원 (fallback)
        window.addEventListener('mapping-changed', this._boundHandleMappingChanged);
        window.addEventListener('mapping-created', this._boundHandleMappingChanged);
        debugLog('📡 Window event listeners registered');
    }
    
    /**
     * ⭐ v3.0.0: 이벤트 리스너 해제
     */
    unregisterEventListeners() {
        if (this.eventBus) {
            this.eventBus.off('mapping-changed', this._boundHandleMappingChanged);
            this.eventBus.off('mapping-created', this._boundHandleMappingChanged);
        }
        
        window.removeEventListener('mapping-changed', this._boundHandleMappingChanged);
        window.removeEventListener('mapping-created', this._boundHandleMappingChanged);
        debugLog('📡 Event listeners unregistered');
    }
    
    /**
     * ⭐ v3.0.0: 새 매핑 발생 시 처리
     * @param {Object|CustomEvent} eventOrData - 이벤트 또는 데이터 객체
     */
    async handleMappingChanged(eventOrData) {
        // CustomEvent인 경우 detail에서 데이터 추출
        const data = eventOrData.detail || eventOrData;
        
        // EquipmentEditState에서 발행하는 이벤트 형식 (camelCase)
        const { frontendId, equipmentId, equipment_id } = data;
        
        // equipment_id 우선 사용 (두 가지 형식 지원: camelCase, snake_case)
        const eqId = equipmentId || equipment_id;
        
        if (!frontendId) {
            debugLog('⚠️ Invalid mapping-changed event data (no frontendId):', data);
            return;
        }
        
        debugLog(`🆕 New mapping detected: ${frontendId} -> equipment_id: ${eqId}`);
        
        try {
            // ============================================
            // 1️⃣ 설비 모델 회색 해제 (원래 색상 복원)
            // ============================================
            if (this.equipmentLoader) {
                this.equipmentLoader.restoreEquipmentStyle(frontendId);
                debugLog(`✅ ${frontendId} model style restored`);
            }
            
            // ============================================
            // 2️⃣ SignalTower 램프 DISABLED 해제 (OFF 상태로)
            // ============================================
            if (this.signalTowerManager) {
                this.signalTowerManager.clearDisabledState(frontendId);
                debugLog(`✅ ${frontendId} SignalTower enabled`);
            }
            
            // ============================================
            // 3️⃣ REST API로 해당 설비 최신 Status 조회
            // ⭐ v3.0.0: Frontend ID로 /equipment/{id}/live API 호출
            // ============================================
            const status = await this.fetchSingleEquipmentStatus(frontendId);
            
            if (status) {
                // ============================================
                // 4️⃣ 해당 Status에 맞는 램프 ON
                // ============================================
                if (this.signalTowerManager) {
                    this.signalTowerManager.updateStatus(frontendId, status);
                    debugLog(`✅ ${frontendId} lamp set to ${status}`);
                }
                
                // 캐시 업데이트
                this.statusCache.set(frontendId, status);
            }
            
            // ============================================
            // 5️⃣ WebSocket Subscribe 목록에 추가
            // ============================================
            if (eqId) {
                this.sendSubscribeForNewMapping(eqId);
                debugLog(`✅ ${frontendId} subscribed to WebSocket (equipment_id: ${eqId})`);
            }
            
            // ============================================
            // 6️⃣ 통계 패널 업데이트
            // ============================================
            this.updateStatusPanel();
            
            // Toast 알림
            this.showToast(`✅ ${frontendId} 연결됨 (Status: ${status || 'Unknown'})`, 'success');
            
        } catch (error) {
            console.error(`❌ Failed to handle new mapping for ${frontendId}:`, error);
            this.showToast(`⚠️ ${frontendId} 연결 처리 실패`, 'error');
        }
    }
    
    /**
     * ⭐ v3.0.0: 특정 설비의 최신 Status 조회
     * Backend API: GET /api/monitoring/equipment/{frontend_id}/live
     * 
     * @param {string} frontendId - Frontend ID (예: 'EQ-01-01')
     * @returns {Promise<string|null>} Status ('RUN', 'IDLE', 'STOP') 또는 null
     */
    async fetchSingleEquipmentStatus(frontendId) {
        try {
            // ⭐ v3.0.0: 올바른 API 엔드포인트 사용
            const response = await fetch(`${this.apiBaseUrl}/equipment/${frontendId}/live`);
            
            if (!response.ok) {
                debugLog(`⚠️ Failed to fetch status for: ${frontendId} (HTTP ${response.status})`);
                return null;
            }
            
            const data = await response.json();
            
            // Backend 응답 형식: { equipment_id, status: {...}, production: {...}, timestamp }
            // status 객체 내부에서 현재 상태 추출
            if (data.status) {
                // status가 객체인 경우 (예: { status: 'RUN', temperature: 25.5, ... })
                if (typeof data.status === 'object' && data.status.status) {
                    return data.status.status;
                }
                // status가 문자열인 경우
                if (typeof data.status === 'string') {
                    return data.status;
                }
            }
            
            debugLog(`⚠️ Could not extract status from response for: ${frontendId}`);
            return null;
            
        } catch (error) {
            console.error(`❌ Error fetching status for ${frontendId}:`, error);
            return null;
        }
    }
    
    /**
     * ⭐ v3.0.0: 새 매핑된 설비를 WebSocket Subscribe에 추가
     * @param {number} equipmentId - Equipment ID (DB ID)
     */
    sendSubscribeForNewMapping(equipmentId) {
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
            debugLog('⚠️ WebSocket not ready for subscribe');
            return;
        }
        
        const subscribeMessage = {
            action: 'subscribe',
            equipment_ids: [equipmentId]
        };
        
        this.ws.send(JSON.stringify(subscribeMessage));
        debugLog(`📡 Subscribed to new equipment_id: ${equipmentId}`);
    }
    
    // ============================================
    // 통계 패널 관리
    // ============================================
    
    createStatusPanel() {
        this.removeStatusPanel();
        
        const panel = document.createElement('div');
        panel.id = 'monitoring-status-panel';
        panel.className = 'status-panel';
        
        this.updateStats();
        panel.innerHTML = this.getStatusPanelHTML();
        
        document.body.appendChild(panel);
        this.statusPanelElement = panel;
        
        debugLog('📊 Status panel created');
    }
    
    getStatusPanelHTML() {
        const { mapped, unmapped, rate } = this.currentStats;
        
        // ⭐ v3.0.0: SignalTower 통계 추가
        let signalTowerStats = '';
        if (this.signalTowerManager) {
            const stats = this.signalTowerManager.getStatusStatistics();
            signalTowerStats = `
                <div class="status-divider">|</div>
                <div class="status-item">
                    <span class="status-icon" style="color: #00ff00;">●</span>
                    <span class="status-value">${stats.RUN}</span>
                </div>
                <div class="status-item">
                    <span class="status-icon" style="color: #ffff00;">●</span>
                    <span class="status-value">${stats.IDLE}</span>
                </div>
                <div class="status-item">
                    <span class="status-icon" style="color: #ff0000;">●</span>
                    <span class="status-value">${stats.STOP}</span>
                </div>
            `;
        }
        
        return `
            <div class="status-item">
                <span class="status-icon connected">✅</span>
                <span class="status-value">${mapped}개 연결</span>
            </div>
            <div class="status-divider">|</div>
            <div class="status-item">
                <span class="status-icon disconnected">⚠️</span>
                <span class="status-value">${unmapped}개 미연결</span>
            </div>
            <div class="status-divider">|</div>
            <div class="status-item">
                <span class="status-icon">📊</span>
                <span class="status-value">${rate}% 완료</span>
            </div>
            ${signalTowerStats}
        `;
    }
    
    updateStats() {
        if (!this.equipmentLoader || !this.equipmentEditState) {
            return;
        }
        
        const totalEquipment = this.equipmentLoader.equipmentArray?.length || 0;
        const mappedCount = this.equipmentEditState.getMappingCount() || 0;
        const unmappedCount = totalEquipment - mappedCount;
        const rate = totalEquipment > 0 ? Math.round((mappedCount / totalEquipment) * 100) : 0;
        
        this.currentStats = {
            mapped: mappedCount,
            unmapped: unmappedCount,
            total: totalEquipment,
            rate: rate
        };
    }
    
    updateStatusPanel() {
        if (!this.statusPanelElement) return;
        
        this.updateStats();
        this.statusPanelElement.innerHTML = this.getStatusPanelHTML();
    }
    
    removeStatusPanel() {
        if (this.statusPanelElement) {
            this.statusPanelElement.remove();
            this.statusPanelElement = null;
            debugLog('📊 Status panel removed');
        }
        
        const existingPanel = document.getElementById('monitoring-status-panel');
        if (existingPanel) {
            existingPanel.remove();
        }
    }
    
    getStats() {
        this.updateStats();
        return { ...this.currentStats };
    }
    
    // ============================================
    // 미연결 설비 클릭 안내
    // ============================================
    
    checkAndNotifyUnmapped(frontendId) {
        if (!this.isActive) return true;
        
        const isMapped = this.isEquipmentMapped(frontendId);
        
        if (!isMapped) {
            this.showUnmappedNotification(frontendId);
            return false;
        }
        
        return true;
    }
    
    showUnmappedNotification(frontendId) {
        this.showToast(
            `⚠️ "${frontendId}"는 DB에 연결되지 않았습니다. Edit Mode (E키)에서 매핑해주세요.`,
            'warning',
            5000
        );
        
        debugLog(`⚠️ Unmapped equipment clicked: ${frontendId}`);
    }
    
    // ============================================
    // 미연결 설비 비활성화 표시
    // ============================================
    
    applyUnmappedEquipmentStyle() {
        if (!this.equipmentLoader || !this.equipmentEditState) {
            debugLog('⚠️ EquipmentLoader or EditState not available');
            return;
        }
        
        const mappings = this.equipmentEditState.getAllMappings();
        const result = this.equipmentLoader.applyMonitoringModeVisibility(
            mappings, 
            this.disabledOptions
        );
        
        this.currentStats.mapped = result.mapped;
        this.currentStats.unmapped = result.unmapped;
        this.currentStats.total = result.mapped + result.unmapped;
        this.currentStats.rate = this.currentStats.total > 0 
            ? Math.round((result.mapped / this.currentStats.total) * 100) 
            : 0;
        
        debugLog(`🌫️ Unmapped equipment disabled: ${result.unmapped}개`);
        debugLog(`✅ Mapped equipment active: ${result.mapped}개`);
        
        // Toast 알림 (미연결이 있을 때만)
        if (result.unmapped > 0) {
            this.showToast(
                `⚠️ ${result.unmapped}개 설비가 DB에 연결되지 않음`, 
                'warning'
            );
        }
    }
    
    resetEquipmentStyle() {
        if (!this.equipmentLoader) {
            debugLog('⚠️ EquipmentLoader not available');
            return;
        }
        
        this.equipmentLoader.resetAllEquipmentVisibility();
        debugLog('✅ All equipment styles reset');
    }
    
    setDisabledOptions(options) {
        this.disabledOptions = { ...this.disabledOptions, ...options };
        
        if (this.isActive) {
            this.applyUnmappedEquipmentStyle();
            this.updateStatusPanel();
        }
    }
    
    showToast(message, type = 'info', duration = 5000) {
        if (window.toast?.show) {
            window.toast.show(message.replace(/\n/g, ' '), type);
            return;
        }
        
        let toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toast-container';
            toastContainer.className = 'toast-container';
            document.body.appendChild(toastContainer);
        }
        
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = message.replace(/\n/g, '<br>');
        toastContainer.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100px)';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }
    
    // ============================================
    // API 및 WebSocket
    // ============================================
    
    async loadInitialStatus() {
        debugLog('📡 Loading initial equipment status...');
        
        const response = await fetch(`${this.apiBaseUrl}/status`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.equipment || !Array.isArray(data.equipment)) {
            throw new Error('Invalid response format');
        }
        
        debugLog(`✅ Loaded ${data.equipment.length} equipment status`);
        
        // REST API 응답에서 frontend_id 또는 equipment_id 사용
        data.equipment.forEach(item => {
            let frontendId = null;
            
            // frontend_id가 있으면 사용
            if (item.frontend_id) {
                frontendId = item.frontend_id;
            }
            // equipment_id로 frontend_id 조회
            else if (item.equipment_id && this.equipmentEditState) {
                frontendId = this.equipmentEditState.getFrontendIdByEquipmentId(item.equipment_id);
            }
            
            if (frontendId && item.status) {
                if (this.isEquipmentMapped(frontendId)) {
                    this.updateEquipmentStatus(frontendId, item.status);
                }
            }
        });
    }
    
    isEquipmentMapped(frontendId) {
        if (!this.equipmentEditState) return true;
        return this.equipmentEditState.isComplete(frontendId);
    }
    
    /**
     * 매핑된 모든 equipment_id 목록 반환
     * @returns {number[]} Equipment ID 배열
     */
    getMappedEquipmentIds() {
        if (!this.equipmentEditState) {
            return [];
        }
        return this.equipmentEditState.getAllEquipmentIds();
    }
    
    connectWebSocket() {
        debugLog(`📡 Connecting to WebSocket: ${this.wsUrl}`);
        
        try {
            this.ws = new WebSocket(this.wsUrl);
            
            this.ws.onopen = () => {
                debugLog('✅ WebSocket connected');
                this.reconnectAttempts = 0;
                
                // 연결 후 subscribe 메시지 전송
                this.sendSubscribeMessage();
            };
            
            this.ws.onmessage = (event) => {
                this.handleWebSocketMessage(event);
            };
            
            this.ws.onerror = (error) => {
                console.error('❌ WebSocket error:', error);
            };
            
            this.ws.onclose = () => {
                debugLog('🔴 WebSocket closed');
                
                if (this.isActive && this.reconnectAttempts < this.maxReconnectAttempts) {
                    this.reconnectAttempts++;
                    debugLog(`🔄 Reconnecting... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
                    
                    setTimeout(() => {
                        this.connectWebSocket();
                    }, this.reconnectDelay);
                }
            };
            
        } catch (error) {
            console.error('❌ Failed to create WebSocket:', error);
        }
    }
    
    /**
     * WebSocket subscribe 메시지 전송
     * 매핑된 모든 equipment_id를 구독 요청
     */
    sendSubscribeMessage() {
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
            debugLog('⚠️ WebSocket not ready for subscribe');
            return;
        }
        
        const equipmentIds = this.getMappedEquipmentIds();
        
        if (equipmentIds.length === 0) {
            debugLog('⚠️ No mapped equipment to subscribe');
            return;
        }
        
        const subscribeMessage = {
            action: 'subscribe',
            equipment_ids: equipmentIds
        };
        
        this.ws.send(JSON.stringify(subscribeMessage));
        debugLog(`📡 Subscribe message sent: ${equipmentIds.length} equipment IDs`);
    }
    
    /**
     * WebSocket 메시지 핸들러 (equipment_id → frontend_id 변환)
     */
    handleWebSocketMessage(event) {
        try {
            const data = JSON.parse(event.data);
            
            // 연결 확인 메시지
            if (data.type === 'connected') {
                debugLog(`📡 WebSocket: ${data.message}`);
                return;
            }
            
            // 구독 확인 메시지
            if (data.type === 'subscribed') {
                debugLog(`📡 WebSocket subscribed: ${data.message}`);
                return;
            }
            
            // Pong 메시지 (heartbeat)
            if (data.type === 'pong') {
                return;
            }
            
            // equipment_status 처리 - equipment_id → frontend_id 변환
            if (data.type === 'equipment_status') {
                let frontendId = null;
                
                // 1. frontend_id가 있으면 직접 사용 (향후 Backend 개선 시)
                if (data.frontend_id) {
                    frontendId = data.frontend_id;
                }
                // 2. equipment_id로 frontend_id 조회 (현재 방식)
                else if (data.equipment_id && this.equipmentEditState) {
                    frontendId = this.equipmentEditState.getFrontendIdByEquipmentId(data.equipment_id);
                }
                
                if (!frontendId) {
                    debugLog(`⚠️ No frontend_id found for equipment_id: ${data.equipment_id}`);
                    return;
                }
                
                // 매핑된 설비만 처리
                if (this.isEquipmentMapped(frontendId)) {
                    debugLog(`📊 Status update: ${frontendId} (equipment_id: ${data.equipment_id}) -> ${data.status}`);
                    this.updateEquipmentStatus(frontendId, data.status);
                } else {
                    debugLog(`⚠️ Equipment not mapped: ${frontendId}`);
                }
            }
            
        } catch (error) {
            console.error('❌ Failed to parse WebSocket message:', error);
        }
    }
    
    updateEquipmentStatus(frontendId, status) {
        const cached = this.statusCache.get(frontendId);
        if (cached === status) {
            return;
        }
        
        this.statusCache.set(frontendId, status);
        
        this.updateQueue.push({
            frontendId: frontendId,
            status: status,
            timestamp: Date.now()
        });
    }
    
    startBatchProcessing() {
        if (this.batchTimer) {
            clearInterval(this.batchTimer);
        }
        
        this.batchTimer = setInterval(() => {
            this.flushUpdateQueue();
        }, this.batchInterval);
        
        debugLog('⏱️ Batch processing started');
    }
    
    flushUpdateQueue() {
        if (this.updateQueue.length === 0) {
            return;
        }
        
        debugLog(`🔄 Processing ${this.updateQueue.length} status updates...`);
        
        this.updateQueue.forEach(update => {
            if (this.signalTowerManager) {
                this.signalTowerManager.updateStatus(
                    update.frontendId,
                    update.status
                );
            }
        });
        
        // ⭐ v3.0.0: 배치 처리 후 패널 업데이트
        this.updateStatusPanel();
        
        this.updateQueue = [];
    }
    
    /**
     * 테스트용: 특정 설비 상태 변경
     * @param {string} frontendId - Frontend ID (예: 'EQ-01-01')
     * @param {string} status - 상태 ('RUN', 'IDLE', 'STOP')
     */
    testStatusChange(frontendId, status) {
        debugLog(`🧪 Test status change: ${frontendId} -> ${status}`);
        this.updateEquipmentStatus(frontendId, status);
        this.flushUpdateQueue();
    }
    
    /**
     * 테스트용: equipment_id로 상태 변경
     * @param {number} equipmentId - Equipment ID (예: 75)
     * @param {string} status - 상태 ('RUN', 'IDLE', 'STOP')
     */
    testStatusChangeByEquipmentId(equipmentId, status) {
        const frontendId = this.equipmentEditState?.getFrontendIdByEquipmentId(equipmentId);
        
        if (!frontendId) {
            console.warn(`⚠️ No mapping found for equipment_id: ${equipmentId}`);
            return;
        }
        
        debugLog(`🧪 Test status change by equipment_id: ${equipmentId} -> ${frontendId} -> ${status}`);
        this.updateEquipmentStatus(frontendId, status);
        this.flushUpdateQueue();
    }
    
    /**
     * ⭐ v3.0.0: 테스트용: 새 매핑 이벤트 시뮬레이션
     * @param {string} frontendId - Frontend ID
     * @param {number} equipmentId - Equipment ID
     */
    testNewMapping(frontendId, equipmentId) {
        debugLog(`🧪 Simulating new mapping: ${frontendId} -> ${equipmentId}`);
        
        this.handleMappingChanged({
            frontendId: frontendId,
            equipmentId: equipmentId
        });
    }
    
    getConnectionStatus() {
        return {
            isActive: this.isActive,
            wsConnected: this.ws && this.ws.readyState === WebSocket.OPEN,
            reconnectAttempts: this.reconnectAttempts,
            cacheSize: this.statusCache.size,
            queueLength: this.updateQueue.length,
            mappedCount: this.equipmentEditState?.getMappingCount() || 0,
            subscribedEquipmentIds: this.getMappedEquipmentIds().length,
            stats: this.currentStats,
            signalTowerStats: this.signalTowerManager?.getStatusStatistics() || null
        };
    }
    
    /**
     * 디버그 정보 출력
     */
    debugPrintStatus() {
        console.group('🔧 MonitoringService Debug Info');
        console.log('Version: 3.0.0');
        console.log('Connection Status:', this.getConnectionStatus());
        console.log('Status Cache:', Object.fromEntries(this.statusCache));
        console.log('Update Queue:', this.updateQueue);
        
        if (this.equipmentEditState) {
            console.log('Equipment ID Index (first 10):', 
                Object.fromEntries(
                    Object.entries(this.equipmentEditState.getEquipmentIdIndex()).slice(0, 10)
                )
            );
        }
        
        if (this.signalTowerManager) {
            this.signalTowerManager.debugPrintStatus();
        }
        
        console.groupEnd();
    }
    
    dispose() {
        debugLog('MonitoringService 메모리 정리 시작...');
        
        this.stop();
        this.statusCache.clear();
        this.updateQueue = [];
        
        debugLog('✓ MonitoringService 메모리 정리 완료');
    }
}